<?php
/* ------------------------------------------------------------------------------
	
	eBookCMS Tiny 1.62
	Stable Release date: January 15, 2014
	Copyright (c) Rui Mendes
	eBookCMS is licensed under a "Creative Commons License"
	
 ------------------------------------------------------------------------------ */

	if (!defined('SECURE_ID') && SECURE_ID == '1234') {die('ACCESS DENIED');}
	require('framework.php');

// LOGIN FIRST TIME
function admin_myfirsttime() {
	$id = decryptRSA($_SESSION[HURI]['user_id']);
	$ks = decryptRSA($_SESSION[HURI][encryptRSA('user_security')]); $gm = load_value('user_gm');
	$data = retrieve_mysql('users', 'id', $id, 'first_login', ' AND key_security = "'.$ks.'"');
	if (isset($data) && !$data['first_login']) {unset($data); set_error(); return;}
	if ($id == 1) {$extended = "input_dtext,username,username,biglength,true,64,64";} else {$extended = "none";}
	$form['action'] = 'myfirsttime';
	$form['myprofile_id'] = $id;
	$form['myprofile_ukey'] = $ks;
	$form['query_table'] = 'users';
	$form['fields'] = array (
		"open_fieldset,personal_data,1,0,0", $extended,
			"input_dtext,emailreg,emailreg,biglength,true,64,64",
			"input_dtext,secretQuestion,secretQuestion,biglength,true,64,64",
			"input_dtext,secretAnswer,secretAnswer,biglength,true,64,64",
			"savefield,first_login,0,i",
			"same_value,avatar,emailreg",
			"same_value,email,emailreg",
		"close_fieldset"
	);
	$form['edit_ks'] = 'key_security';
	$form['cancel'] = true;
	$form['back_to'] = isAllowed('root_access') ? 'root' : 'personal_data';
	create_form($form);
}

// ADMIN MY PROFILE
function admin_myprofile() {
	$form['action'] = 'myprofile';
	$form['myprofile_id'] = decryptRSA($_SESSION[HURI]['user_id']);
	$form['myprofile_ukey'] = decryptRSA($_SESSION[HURI][encryptRSA('user_security')]);
	$form['query_table'] = 'users';
	$form['fields'] = array (
		"open_fieldset,personal_data,1,0,0",
		"input_dtext,realname,realname,biglength,true,64,64",
		"input_dtext,avatar,avatar,biglength,false,100,128",
		"input_dtext,email,email,biglength,true,100,128",
		"input_dtext,website,website,biglength,false,100,128",
		"close_fieldset"
	);
	$form['edit_ks'] = 'key_security';
	$form['cancel'] = true;
	$form['back_to'] = isAllowed('root_access') && !isset($_POST['pd']) ? 'root' : 'personal_data';
	create_form($form);
}

// ADMIN SETUP
function admin_config() { global $get;
	$form['action'] = 'config';
	$form['title'] = 'config';
	$form['query_table'] = 'config';
	$form['table_header'] = t('id').','.t('title').','.t('action');
	$form['table_cspans'] = '1,1,1';
	$form['table_hsize'] = '15%,55%,15%';
	$form['table_fields'] = 'id,field,%edit';
	$form['query_where'] = isset($get['fg']) ? ' WHERE fgroup = '.$get['fg'] : '';
	$form['fields'] = array (
		"open_fieldset,admin_place,1,0,0",
		"input_rtext,field,field,biglength,false,60,60"
	);
	if (isset($get['tid'])) {$id = $get['tid'];}
	else {$id = isset($_POST['id']) ? decryptRSA(clean($_POST['id'])) : null;}
	switch ($id){
		case  3 : $form['fields'][] = "combolist,value,value,charset_list,false,1,1"; break;
		case  7 : 
			$form['fields'][] = "combotable,value,value,languages,false,id@title@prefixo,enabled=1,,1,false,prefixo,s";
		break;
		case 10 : case 11 : case 12 : case 13 : case 14 : case 15 : case 16 : case 17 : case 18 : case 19 : 
		case 27 : case 28 :
			$form['fields'][] = "multichoice,value,edit_by,gm_list,1,2"; break;
		case 20 : case 21 : case 22 : case 23 : case 24 : case 25 : case 26 :
			$form['fields'][] = "input_int,value,value,smalllength,false,60,100"; break;
		case 29 : $form['fields'][] = "combolist,value,value,uactive_list,false,1"; break;
		case 30 : $form['fields'][] = "combolist,value,value,gm_list,false,1"; break;
		case 31 : case 33 : $form['fields'][] = "combolist,value,value,yes_no,false,1"; break;
		case 32 : $form['fields'][] = "combolist,value,value,asc_desc,false,1,1"; break;
		case 34 : $form['fields'][] = "combolist,value,value,level_comments,false,1"; break;
		case 35 : case 36 : case 37 : case 38 : $form['fields'][] = "multichoice,value,edit_by,gm_list,1,2"; break;
		default : $form['fields'][] = "input_text,value,value,biglength,false,60,100"; break;
	}
	$form['fields'][] = "close_fieldset";
	$form['edit_ks'] = 'key_security';
	$form['keys'] = 'key_security';
	$form['edit_id'] = '1';
	$form['cancel'] = true;
	$form['back_bigroot'] = isAllowed('bigroot_access') ? true : false;
	$form['limits'] = 30;
	$form['edit_rights'] = isAllowed('config_access');
	$form['top_filter_by'] = 'config,fgroup,fg,filter_by,fgroup_list,all';
	create_form($form);
}

// CHANGE MY PASSWORD
function admin_mypassword() { global $get;
	$form['myprofile_id'] = decryptRSA($_SESSION[HURI]['user_id']);
	$form['myprofile_ukey'] = decryptRSA($_SESSION[HURI][encryptRSA('user_security')]);
	$form['action'] = 'mypassword';
	$form['query_table'] = 'users';
	$form['fields'] = array (
		"open_fieldset,personal_data,1,0,0",
		"input_password1,password1,password1,biglength,true,32,32",
		"input_password2,password2,password2,biglength,true,32,32",
		"input_password3,password3,password3,biglength,true,32,32",
		"close_fieldset"
	);
	$form['params'] = 'si';
	$form['change_password'] = "password,password1,password2,password3";
	$form['edit_ks'] = 'key_security';
	$form['cancel'] = true;
	$form['back_to'] = isAllowed('root_access') && !isset($_POST['pd']) ? 'root' : 'personal_data';
	create_form($form);
}

// ADMIN LANGUAGES
function admin_langs() { global $get;
	$form['action'] = 'langs';
	$form['query_table'] = 'languages';
	$form['subtitle1'] = t('langs_list');
	$form['table_header'] = t('order').','.t('title').','.t('action');
	$form['table_cspans'] = '1,1,2';
	$form['table_hsize'] = '15%,55%,15%,15%';
	$form['table_fields'] = '%order,title,%edit,%delete';
	if ($get['action'] == 'edit'){
		$tid = $get['tid'];
		$pages_id = "combotable,page_id,page_id,pages,false,id@title,(published = 1 OR published = 2) ";
		$pages_id.= "AND lang_id = $tid,0@none,0,,,i";
	} else {$pages_id = '';}
	$form['fields'] = array (
		"open_fieldset,admin_place,1,0,0",
			"checkbox,enabled,enabled,1", "br",
			"input_text,title,title,biglength,true,60,60",
			"input_text,seftitle,seftitle,biglength,true,60,60",
			"input_text,prefixo,prefixo,biglength,true,2,2",
			$pages_id,
			"checkboxscrip,use_prefix,use_prefix,1,d_flag,d_flag", "br",
			"open_Div,d_flag,use_prefix,1",
			"open_fieldset,f_flag,1,0,0",
				"comboimage,image_li,image_li,js/langs,.jpg|.gif|.png,16px,11px,sflag",
			"close_fieldset",
			"close_Div",
			"combolist,charset,charset,charset_list,false,0",
			"genSEF,seftitle,title",
		"close_fieldset"
	);
	$form['keys'] = 'key_security,del_key';
	$form['edit_ks'] = 'key_security';
	$form['delkey'] = 'del_key';
	$form['delete_id'] = '1';
	$form['order'] = true;
	$form['table_order'] = 'id';
	$form['cancel'] = true;
	$form['noduplicates'] = 'seftitle,prefixo';
	$form['limits'] = load_cfg('langs_limit');
	$form['back_bigroot'] = true;
	$form['edit_rights'] = isAllowed('lang_access');
	$form['delete_rights'] = isAllowed('lang_access');
	create_form($form);
}

// ADMIN SECTIONS
function admin_sections($action = 'sections', $backbig = true) {
	$form['action'] = $action;
	$form['taction'] = 'sections';
	$form['query_table'] = 'sections';
	$form['subtitle1'] = t('sections_list');
	$form['table_header'] = t('order').','.t('title').','.t('action');
	$form['table_cspans'] = '1,1,3';
	$form['table_fields'] = '%order,title,%content,%edit,%delete';
	$form['table_hsize'] = '15%,45%,12%,12%,12%';
	$form['fields'] = array (
		"open_fieldset,admin_place,1,0,0",
			"checkbox,enabled,enabled,1", "br",
			"input_text,title,title,biglength,true,32,32",
			"input_text,seftitle,seftitle,biglength,true,32,32",
			"combolist,group_by,group_by,menu_sections,false,0",
			"comboscript,sec_type,sec_type,type_sections,false,0",
			"choice_Div,sec_type2,sec_type,2",
				"combotable,plug_id,plug_id,plugins,false,id@title,enabled=1,0@noaction,0,,,i",
			"close_Div",
			"input_text,csstype,csstype,biglength,false,16,16",
			"input_int,lcontent,lcontent,biglength,false,16,16,0",
			"genSEF,seftitle,title",
		"close_fieldset"
	);
	$gm = load_value('user_gm');
	if ($gm == 1 && isAllowed('enable_poptions')){
		$form['fields'][] = "choice_Div,sec_type1,sec_type,1";
			$form['fields'][] = "open_fieldset,admin_options,1,1,0";
				$form['fields'][] = "checkbox,only_author,only_author,1";
				$form['fields'][] = "checkbox,option_txt1,option_txt1,1";
				$form['fields'][] = "checkbox,option_txt2,option_txt2,0";
				$form['fields'][] = "checkbox,show_lang,show_lang,0";
				$form['fields'][] = "checkbox,show_date,show_date,0";
				$form['fields'][] = "checkboxscrip,option_img,option_img,0,d_img,d_img";
				$form['fields'][] = "br";
				$form['fields'][] = "open_Div,d_img,option_img,1";
					$form['fields'][] = "input_text,image_folder,image_folder,biglength,false,32,32";
				$form['fields'][] = "close_Div";
			$form['fields'][] = "close_fieldset";
		$form['fields'][] = "close_Div";
		$form['fields'][] = "open_fieldset,admin_rights,1,1,0";
			$form['fields'][] = "multichoice,admin_by,admin_by,gm_list,1,1";
			$form['fields'][] = "multichoice,edit_by,edit_by,gm_list,1,1";
			$form['fields'][] = "multichoice,delete_by,delete_by,gm_list,1,1";
			$form['fields'][] = "multichoice,add_content,add_content,member_list,1,1";
			$form['fields'][] = "multichoice,member_by,member_by,member_list,0,0";
		$form['fields'][] = "close_fieldset";
	}
	$form['content_fields'] = 'id,order_content,title,sec_type,plug_id,admin_by,only_author,add_content,member_by,'.
		'lcontent';
	$form['control_content'] = 'sec_type';
	$form['control_rights'] = 'admin_by';
	$backlink = $action == 'asections' ? "backlink,false,".$action.",list" : "backlink,false,root";
	# Pages
	$form['content'][1] = array (
		"new_content,add_page,pages,new,tid,id",
		"drawtable,pages,ptype,sections,id@order_content@title@seftitle@author_id@key_security@del_key,section_id=%id ".
		"%lang_id,order@title@seftitle@action,%order@title@seftitle@%edit@%delete,1@1@1@2,10%@20%@40%@15%@15%,".
		load_cfg('pages_limit').",ORDER BY order_content ASC",
		"end_table", 
		"filter,langs,languages,id@prefixo,enabled = 1,lang,prefixo", $backlink
	);
	$form['section_id'] = 'sec_type';
	$form['del_herited'][1] = 'pages,ptype = 0 AND section_id=%id %lang_id';
	// EDIT/DELETE content by ID - $form['edit_content'][1] = '1'; $form['del_content'][1] = '1'; 
	$form['del_section_id'][1] = '1';
	$form['noduplicates'] = 'seftitle';
	$form['limits'] = load_cfg('sections_limit');
	$form['keys'] = 'key_security,del_key';
	$form['edit_ks'] = 'key_security';
	$form['delkey'] = 'del_key';
	$form['order'] = true;
	$form['table_order'] = 'order_content';
	$form['cancel'] = true;
	$form['back_to'] = 'asections,list';
	if ($backbig !== false){$form['back_bigroot'] = $backbig;}
	$form['edit_rights'] = isAllowed('section_access');
	$form['delete_rights'] = isAllowed('section_access');
	create_form($form);
}

// ADMIN PAGES
function admin_pages($action, $type){ global $get;
	$form['taction'] = 'pages';
	$form['action'] = $action;
	$form['query_table'] = 'pages';
	$form['subtitle1'] = t('add_page');
	$form['table_header'] = t('order').','.t('title').','.t('action');
	$form['table_cspans'] = '1,1,2';
	$form['table_fields'] = '%order,title,%edit,%delete';
	$form['inherited'] = 'sections';
	$form['inherited_id'] = 'section_id';
	if (isset($get['tid'])) {$cid = decryptRSA($get['tid']);} else {$cid = '0';}
	# GET RIGHTS
	if ($get['action'] == 'edit' || $get['action'] == 'save') {
		if ($get['action'] == 'edit' && isset($get['tid'])) {$sid = $get['tid'];}
		if ($get['action'] == 'save' && isset($_POST['id'])) {$sid = decryptRSA(clean($_POST['id']));}
		if (isset($sid) && $sid != 0){
			$data = retrieve_mysql('pages', 'id', $sid, 'section_id', '');
			$id = isset($data['section_id']) ? $data['section_id'] : decryptRSA(clean($_POST['section_id']));
		} else {$id = $cid;}
	} else {$id = $get['action'] == 'new' && isset($cid) ? $cid : $get['tid'];}
	$fields = 'image_folder, option_txt1, option_txt2, option_img, show_lang, show_date';
	$data = retrieve_mysql('sections', 'id', $id, $fields, '');
	# TEXT
	if ($data && isset($data['option_txt1']) && $data['option_txt1'] == 1) {$text = "text_area,texto1,text";}
	else if ($data && isset($data['option_txt1']) && $data['option_txt1'] == 0) {$text = "none";}
	else {$text = "text_area,texto1,texto1";}
	# FIELDS
	$form['fields'] = array (
		"open_fieldset,admin_place,1,0,0",
		"input_text,title,title,biglength,true,100,100",
		"input_text,seftitle,seftitle,biglength,true,100,100",
		$text, 
		"checkbox,showtitle,showtitle,1", "br",
		"combolist,published,published,page_list,false,1",
		"combolist,comments,comments,comments_list,false,0"
	);
	$lang_id = load_value('lang');
	if ($data && isset($data['show_lang']) && $data['show_lang'] == 1) {
		$form['fields'][] = "combotable,lang_id,lang_id,languages,false,id@title,enabled=1,0@none,".$lang_id.",,,i";
	} else {$form['fields'][] = "newhidden,lang_id,".$lang_id.',i';}
	$user_id = load_value('user_id');
	$form['fields'][] = "newhidden,section_id,".$cid.',i';
	$form['fields'][] = "newhidden,author_id,".$user_id.',i';
	$form['fields'][] = "genSEF,seftitle,title";
	$form['fields'][] = "close_fieldset";
	# OPTIONS
	$gm = load_value('user_gm');
	if ($gm == 1 && load_cfg('enable_poptions')){
		$form['fields'][] = "open_fieldset,admin_options,1,1,0";
			# DATE
			$now = date('Y-m-d H:i:s');
			if ($data && isset($data['show_date']) && $data['show_date'] == 1){
				$form['fields'][] = "choose_date,date_upd,date_upd,2010,2017,".$now;
				$form['fields'][] = "same_newvalue,date_reg,date_upd,s";
				$form['fields'][] = "br";
			} else {
				$form['fields'][] = "newfield_date,date_reg,".$now.',s';
				$form['fields'][] = "newfield_date,date_upd,".$now.',s';
				$form['fields'][] = "updatefield,date_upd,".$now;
			}
			# CSS
			$form['fields'][] = "input_text,pcsstype,csstype,biglength,false,16,16";
			# DMETA & KEYWORDS
			$dmeta = str_replace(',','|', load_cfg('description'));
			$keywords = str_replace(',', '|', load_cfg('web_keywords'));
			$form['fields'][] = "input_text,dmeta,dmeta,biglength,false,100,128,".$dmeta;
			$form['fields'][] = "input_tags,keywords,keywords,biglength,false,100,128";
		$form['fields'][] = "close_fieldset";
	} else {
		$form['fields'][] = "newfield_date,date_reg,".$now.',s';
		$form['fields'][] = "newfield_date,date_upd,".$now.',s';
		$form['fields'][] = "updatefield,date_upd,".$now;
	}
	# IMAGE
	$dir = $data && isset($data['image_folder']) ? 'images/'.$data['image_folder'] : 'images';
	if (($data && isset($data['option_img']) && $data['option_img'] == 1) || ($get['action'] == 'save')){
		$form['fields'][] = "open_fieldset,admin_image,1,0,0";
		$form['fields'][] = "comboimage,image,image,".$dir.",.jpg|.gif|.png,128px,128px,select_image";
		$form['fields'][] = "close_fieldset";
	}
	$form['noduplicates'] = 'seftitle';
	$form['limits'] = load_cfg('pages_limit');
	$form['keys'] = 'key_security,del_key';
	$form['edit_ks'] = 'key_security';
	$form['order'] = true;
	$form['table_order'] = 'id';
	$form['order_where'] = ' WHERE ptype='.$type.' AND section_id = %section_id %lang_id';
	$form['order_fields'] = 'ptype@%ptype,section_id@%section_id';
	$form['limits'] = load_cfg('pages_limit');
	$form['only_author'] = 'author_id';
	$form['cancel'] = true;
	$form['delete_id'] = '1';
	$form['back_bigroot'] = false;
	$form['back_id'] = 'pages,id';
	$form['back_sid'] = 'sections,content,section_id';
	$form['edit_rights'] = isAllowed('page_edit');
	$form['delete_rights'] = isAllowed('page_delete');
	create_form($form);
}


// ADMIN USERS
function admin_users() { global $get;
	$form['taction'] = 'users';
	$form['action'] = 'users';
	$form['query_table'] = 'users';
	$form['subtitle1'] = t('users_list');
	$form['table_header'] = t('id').','.t('username').','.t('realname').','.t('action');
	$form['table_cspans'] = '1,1,1,2';
	$form['table_fields'] = 'id,@username,@realname,%edit,%delete';
	$form['table_hsize'] = '10%,25%,45%,10%,10%';
	$form['query_where'] = isset($get['gm']) ? ' WHERE gmember = '.$get['gm'] : '';
	$gm = load_value('user_gm');
	$user_id = load_value('user_id');
	$ip_address = getInfo('YOUR_IP');
	if ($ip_address == '::1') {$ip_address = '127.0.0.1';}
	$ip_address = encryptRSA($ip_address,false);
	$username = "none"; $pass = "none";
	if ($get['action'] == 'new') {$add_default = $get['action'] == 'new' ? ',test' : '';}
	else {$add_default = '';}
	$active = load_cfg('user_active');
	$usergm = load_cfg('user_member');
	$form_gm = $usergm == 1 || isAllowed('users_edit') ? "combolist,gmember,gmember,gm_list,false,".$usergm : "none";
	$form['fields'] = array (
		"open_fieldset,admin_place,1,0,0",
			"checkbox,first_login,first_login,1", "br",
			"input_ntext,username,username,biglength,true,32,32",
			"create_password,password,cpassword,biglength,true,32,32".$add_default,
			"input_dtext,realname,realname,biglength,true,100,128",
			"input_dtext,emailreg,email,biglength,true,100,255",
			"input_dtext,website,website,biglength,false,100,255",
			"newhidden,user_ip,".$ip_address.',s',
			"newhidden,validation_code,".genKey('validation_code').',s',
			"newhidden,total_timedate,0,i",
			"newhidden,regdate,".date('Y-m-d').',s',
			"newhidden,browser_id,".get_hsa().',s', "hr",
			"combolist,user_active,user_active,uactive_list,false,".$active,
			$form_gm,
			"same_value,avatar,emailreg",
			"same_value,email,emailreg",
		"close_fieldset"
	);
	$form['content_fields'] = 'id,order';
	$form['noduplicates'] = 'username';
	$form['limits'] = load_cfg('users_limit');
	$form['keys'] = 'key_security,del_key';
	$form['edit_ks'] = 'key_security';
	$form['delkey'] = 'del_key';
	$form['table_order'] = 'id';
	$form['cancel'] = true;
	# EDIT USER_ID
	$form['edit_id'] = $user_id == '1' ? '1' : ''.$user_id;
	# DELETE USER_ID
	$form['delete_id'] = $user_id == 1 ? '1' : '1,'.$user_id;
	$form['edit_group'] = $user_id == '1' ? '' : ($gm != '1' ? '1' : '1,'.$gm);
	$form['delete_group'] = $user_id == '1' ? '' : isAllowed('users_delete');
	$form['key_group'] = 'gmember';
	$form['back_bigroot'] = true;
	$form['back_to'] = 'users,list';
	$form['filter_by'] = 'users,gmember,gm,filter_by,gm_list,all_members';
	$form['edit_rights'] = isAllowed('users_edit');
	$form['delete_rights'] = isAllowed('users_delete');
	create_form($form);
}

// WEB TEXT
function cpanel_comments() {
	echo '<h1>'.t('comments').'</h1>';
	$root = getInfo('ROOT').getPHPName(); $uri = '<li><a href="'.$root.'?admin=';
	if (isAllowed('comments_access') != true) {echo '<p>'.t('no_access').'</p>'; return;}
	$action = '&amp;action=list'; $ukey = '&amp;ukey='.load_value('user_ks');
	$admin_msg = isAllowed('comments_access') && isAllowed('admin_messages') ? true : false;
	$block_msg = isAllowed('comments_access') && isAllowed('admin_messages') && isAllowed('block_messages') ? 
		true : false;
	$spam_msg = isAllowed('comments_access') && isAllowed('admin_messages') && isAllowed('spam_messages') ? 
		true : false;
	$archive_msg = isAllowed('comments_access') && isAllowed('admin_messages') && isAllowed('archive_messages') ? 
		true : false;
	echo '<fieldset><legend class="eb_legend">'.t('admin').'</legend>';
		echo '<ul class="admin_links">';
		if ($admin_msg)  {echo $uri.'comok'.$action.$ukey.'">'.t('approved').'</a></li>';}
		if ($admin_msg) {echo $uri.'comwap'.$action.$ukey.'">'.t('comwap').'</a></li>';}
		if ($spam_msg){echo $uri.'comspam'.$action.$ukey.'">'.t('spam').'</a></li>';}
		if ($block_msg) {echo $uri.'combku'.$action.$ukey.'">'.t('combku').'</a></li>';}
		if ($block_msg) {echo $uri.'combke'.$action.$ukey.'">'.t('combke').'</a></li>';}
		if ($archive_msg) {echo $uri.'comarch'.$action.$ukey.'">'.t('comarch').'</a></li>';}
		if ($spam_msg) {echo $uri.'comrep'.$action.$ukey.'">'.t('comrep').'</a></li>';}
		echo '</ul>';
	echo '</fieldset>';
	if (isAllowed('root_access') && isAllowed('bigroot_access')) {
		$link = ' <a href="'.$root.'?admin=bigroot'.$ukey.'">'.t('here').'</a>';
		echo '<p>'.t('back_bigroot').' '.t('click').$link.'</p><br />';
	}
}


// ADMIN COMMENTS
function admin_comments($action, $option, $type, $admin = 'admin_messages') { global $get;
	$form['action'] = $action;
	$form['title'] = $type != 0 ? 'comments' : 'comment';
	$now = date('Y-m-d H:i:s');
	$form['taction'] = 'comments';
	$form['query_table'] = 'comments';
	switch ($type) {
		case 1 : $form['query_where'] = ' WHERE approved = 1 AND archive_comment = 0 AND spam = 0'; break;
		case 2 : $form['query_where'] = ' WHERE approved = 0'; break;
		case 3 : $form['query_where'] = ' WHERE spam = 1'; break;
		case 4 : $form['query_where'] = ' WHERE block_user = 1'; break;
		case 5 : $form['query_where'] = ' WHERE block_email = 1'; break;
		case 6 : $form['query_where'] = ' WHERE archive_comment = 1'; break;
		case 7 : $form['query_where'] = ' WHERE report_abuse = 1 AND spam = 0'; break;
	}
	$form['subtitle1'] = '<h3>'.t($option).'</h3>';
	$form['table_header'] = t('name').','.t('avatar_email').','.t('ip').','.t('action');
	$form['table_cspans'] = '1,1,1,2';
	$form['table_hsize'] = '25%,30%,13%,10%,153%';
	$form['table_fields'] = '@name,@avatar_email,@user_ip,%edit,%delete';
	$form['fields'] = array (
		"open_fieldset,admin_place,1,0,0",
			"input_dtext,name,name,biglength,true,100,255",
			"input_dtext,avatar_email,avatar_email,biglength,true,100,255",
			"input_dtext,url,url,biglength,false,100,255",
			"text_code,comment,comment",
			"checkbox,approved,approved,1",
			"checkbox,spam,spam,0",
			"checkbox,block_user,block_user,0",
			"checkbox,block_email,block_email,0",
			"checkbox,archive_comment,archive_comment,0", "br",
			"combolist,report_abuse,report_abuse,abuse_list,false,1",
			"combotable,page_id,page,pages,false,id@title,id=[page_id],,1,,,i",
			"combotable,user_id,user,users,false,id@username,id=[user_id],0@anonymous,1,1,,i",
			"newfield_date,date_reg,".$now.',s',
		"close_fieldset"
	);
	$form['keys'] = 'key_security,delkey';
	$form['edit_ks'] = 'key_security';
	$form['delkey'] = 'delkey';
	$form['order_by'] = ' ORDER BY id DESC';
	$form['cancel'] = true;
	$form['limits'] = load_cfg('comments_limit');
	$form['back_to'] = $action.',list';
	$form['back_list'] = isset($get['fp']) && $get['fp'] == 3 ? 'root' : 'comments,list';
	$form['edit_rights'] = isAllowed($admin);
	$form['delete_rights'] = isAllowed($admin);
	create_form($form);
}

// ADMINISTRATION PLUGIN
function admin_iplugins($action) { global $pn, $get;
	$plugdir = 'plugins/';
	# REFRESH DIRECTORY AND PRE-INSTALL PLUGINS
	if (is_dir($plugdir)) {
		$fd = opendir($plugdir); $plug_array = array();
		$plugin_data = retrieve_mysql('plugins', 'preinstalled', 1, 'filename', '', '');
		for ($i=0; $i<count($plugin_data); $i++) {$plug_array[] = $plugin_data[$i]['filename'];}
		while (($file = @readdir($fd)) == true) {
			clearstatcache();
			$ext = substr($file, strrpos($file, '.') + 1);
			if ($ext == 'php' || $ext == 'txt') {
				include_once($plugdir.$file);
				if (!in_array($file, $plug_array)){
					$fname = 'plugin_'.load_value('getfilename', $file);
					call_user_func_array($fname, array('pre-install',$file));
				}
			}
		}
	}
	$form['action'] = 'iplugins';
	$form['query_table'] = 'plugins';
	$form['table_header'] = t('title').','. t('author').','.t('action');
	$form['table_cspans'] = '1,1,4';
	$form['table_fields'] = 'title,author,%install,%edit,%ctable,%dtable';
	$form['table_hsize'] = '30%,22%,15%,15%,15%';
	$form['fields'] = array (
		"open_fieldset,admin_place,1,0,0",
			"checkbox,auto_load,auto_load,1", "br",
			"checkbox,enabled,enabled,1", "br",
			"input_rtext,title,title,biglength,false,80,80",
			"input_rtext,author,author,biglength,false,80,80",
			"input_rtext,version,version,biglength,false,8,8",
			"input_rtext,filename,filename,biglength,false,64,64",
			"input_rtext,install_table,install_table,biglength,false,80,80",
			"input_rtext,sef_file,sef_file,biglength,false,80,80",
			"input_rtext,admin_func,admin_func,biglength,false,64,64",
			"input_rtext,public_func,public_func,biglength,false,64,64",
			"text_rcode,description,description,255",
			"open_fieldset,admin,1,1,0",
				"multichoice,edit_by,edit_by,gm_list,1,1",
				"multichoice,delete_by,delete_by,gm_list,1,1",
			"close_fieldset",
			"open_fieldset,admin_data,1,1,0",
				"input_xtext,xstr1,xtxt1,biglength,false,64,64",
				"input_xtext,xint1,xtxt2,biglength,false,64,64",
				"input_xtext,xdate1,xtxt3,biglength,false,64,64",
			"close_fieldset",
		"close_fieldset"
	);
	$form['keys'] = 'key_security,delkey';
	$form['edit_ks'] = 'key_security';
	$form['delkey'] = 'delkey';
	$form['limits'] = load_cfg('plugins_limit');
	$form['edit_enabled'] = 'installed';
	$form['back_to'] = 'iplugins,list';
	$form['cancel'] = true;
	$form['back_bigroot'] = true;
	$form['edit_rights'] = isAllowed('plugins_install');
	create_form($form);
}

// ADMINISTRATION DATA FROM PLUGIN
function admin_plugins($action) {
	$form['action'] = 'plugins';
	$form['padmin'] = 'sef_file';
	$form['query_table'] = 'plugins';
	$form['table_header'] = t('title').','. t('author').','.t('action');
	$form['table_cspans'] = '1,1,1';
	$form['table_fields'] = 'title,author,%padmin';
	$form['query_where'] = ' WHERE installed = 1';
	$form['table_hsize'] = '55%,30%,12%';
	$form['back_bigroot'] = true;
	$form['edit_rights'] = isAllowed('plugins_access');
	create_form($form);
}

// BIG ROOT FOR SUPER-ADMIN	
function admin_bigroot(){ global $get;
	if (!isAllowed('bigroot_access')) {return;}
	echo '<h1>'.t('panel_control').'</h1>';
	echo '<h2>'.t('admin_place').'</h2>';
	$uri = '<li><a href="'.getInfo('ROOT').getPHPName().'?admin=';
	$ks = load_value('user_ks'); $ukey = isset($ks) ? '&amp;ukey='.$ks : '';
	$list = '&amp;action=list';
	echo '<fieldset><legend class="eb_legend">'.t('advanced_menu').'</legend>';
		echo '<ul class="admin_links">';
		if (isAllowed('config_access')) {echo $uri.'config'.$list.$ukey.'">'.t('config').'</a></li>';}
		if (isAllowed('lang_access')) {echo $uri.'langs'.$list.$ukey.'">'.t('langs').'</a></li>';}
		if (isAllowed('section_access')) {echo $uri.'asections'.$list.$ukey.'">'.t('sections').'</a></li>';}
		if (isAllowed('users_access')) {echo $uri.'users'.$list.$ukey.'">'.t('users').'</a></li>';}
		if (isAllowed('plugins_install')) {echo $uri.'iplugins'.$list.$ukey.'">'.t('plugins_intall').'</a></li>';}
		if (isAllowed('plugins_access')) {echo $uri.'plugins'.$list.$ukey.'">'.t('plugins').'</a></li>';}
		if (isAllowed('comments_access')) {echo $uri.'comments'.$ukey.'">'.t('comments').'</a></li>';}
		echo '</ul>';
	echo '</fieldset>';
	$link = ' <a href="'.getInfo('ROOT').getPHPName().'?admin=root'.$ukey.'">'.t('here').'</a>';
	echo '<p>'.t('back_root').' '.t('click').$link.'</p><br />';
}

// USER ADMINISTRATION
function user_root() {
	$gm = load_value('user_gm');
	if (strlen($gm)==1) {$gm = '0'.$gm;}
	$root = getInfo('ROOT').getPHPName();
	$ukey = LOGGED ? '&amp;ukey='.load_value('user_ks') : '';
	$lang_id = load_value('lang'); $uri = '<li><a href="'.$root.'?admin=';
	if ($lang_id != 1) {$lang = '&amp;lang='.$lang_id;} else {$lang = '';}
	echo '<h1>'.t('panel_control').'</h1>';
	if (isAllowed('root_access')) {
		echo '<h2>'.t('useradmin_place').'</h2>';
		$uri1 = '<li><a href="'.$root.'?admin=sections&amp;action=content&amp;';
		$list = '&amp;action=list'; $edit = '&amp;action=edit';
		$nocontent = true;
		$menus = explode(',', t('menu_sections'));
		for ($i=1; $i<count($menus); $i++){
			$qtotal = "SELECT count(id) AS total 
				FROM ".PREFIX."sections WHERE enabled = 1 AND admin_by LIKE  '%".$gm."%' AND group_by = ?";
			if ($rres = db() -> prepare($qtotal)){
				$rt = dbbind($rres, array($i), 'i');
				$vvalues = dbfetch($rt, true);
				$total = $vvalues['total']; unset($vvalues, $rres);
			}
			$query = "SELECT * FROM ".PREFIX."sections 
				WHERE enabled = 1 AND admin_by LIKE  '%".$gm."%' AND group_by = ?";
			if ($result = db() -> prepare($query)){
				$result = dbbind($result, array($i), 'i');
				if ($total > 0){
					$nocontent = false;
					echo '<fieldset><legend class="eb_legend">'.$menus[$i].'</legend><ul class="admin_links">';
					while ($r = dbfetch($result)) {
						if ($r['sec_type'] != 2) {
						 	$plug_key = encryptRSA($r['key_security'],false);
							echo $uri1.'tid='.$r['id'].'&amp;tks='.$plug_key.$ukey.$lang.'">'.$r['title'].'</a></li>';
						} else {
							$pid = $r['plug_id'];
							$plugin = retrieve_mysql('plugins', 'id', $pid, 'id,sef_file', " AND installed = 1");
							echo $uri.$plugin['sef_file'].'&amp;action=list'.$ukey.$lang.'">'.$r['title'].'</a></li>';
						}
					} echo '</ul></fieldset>';
				}
			} unset($result);
		}
		# MESSAGES - WAITING APPROVAL
		$waiting = retrieve_mysql('comments', 'approved', 0, 'count(DISTINCT id) AS total', '');
		if (isAllowed('comments_access') && isAllowed('admin_messages') && $waiting && $waiting['total'] != 0) {
			echo '<fieldset><legend class="eb_legend">'.t('comwap').'</legend>';
				echo '<ul class="admin_links">';
					echo $uri.'comwap&amp;action=list&amp;fp=3'.$ukey.$lang.'">';
					echo $waiting['total'].' '.t('comments').'</a></li>';
			echo '</ul></fieldset>'; unset($waiting);
		}
		# MESSAGES - REPPORT ERRORS OR SPAM
		$errors = retrieve_mysql('comments', 'report_abuse', 1, 'count(DISTINCT id) AS total', ' AND spam = 0');
		if (isAllowed('comments_access') && isAllowed('spam_messages') && $errors && $errors['total'] != 0) {
			echo '<fieldset><legend class="eb_legend">'.t('comrep').'</legend>';
				echo '<ul class="admin_links">';
					echo $uri.'comrep&amp;action=list&amp;fp=3'.$ukey.$lang.'">';
					echo $errors['total'].' '.t('comments').'</a></li>';
			echo '</ul></fieldset>'; unset($errors);
		}
	} else {echo '<div class="ebook_admin"><div class="msgwarning"><p>'.t('no_access').'</p></div></div>'; return;}
	# PROFILE
	echo '<fieldset><legend class="eb_legend">'.t('f_myprofile').'</legend>';
		echo '<ul class="admin_links">';
		echo $uri.'myprofile&amp;action=edit'.$ukey.$lang.'">'.t('change_profile').'</a></li>';
		echo $uri.'mypassword&amp;action=edit'.$ukey.$lang.'">'.t('mypassword_title').'</a></li>';
		echo '<li><a href="'.$root.'?logout=now">'.t('logout').'</a></li>';
		echo '</ul>';
	echo '</fieldset>';
 	if (isAllowed('root_access') && isAllowed('bigroot_access')) {
		echo '<p>'.t('advanced_func').' '.t('click').' <a href="'.$root.'?admin=bigroot'.$ukey.$lang.'">';
		echo t('here').'</a></p><br />';
	}
}

// PERSONAL DATA
function personal_data($title = true) {
	echo '<div class="ebook_admin">'; $root = getInfo('ROOT').getPHPName();
	if ($title) {echo '<h1>'.t('panel_control').'</h1>';}
	$uri = '<li><a href="'.getInfo('ROOT').getPHPName().'?admin=';
	$ukey = $_SESSION && isset($_SESSION[HURI][encryptRSA('user_security')]) ? 
		'&amp;ukey='.$_SESSION[HURI][encryptRSA('user_security')] : '';
	echo '<fieldset><legend class="eb_legend">'.t('f_myprofile').'</legend>';
		echo '<ul class = "admin_links">';
			echo $uri.'myprofile&amp;action=edit&amp;pd=1'.$ukey.'">'.t('change_profile').'</a></li>';
			echo $uri.'mypassword&amp;action=edit&amp;pd=1'.$ukey.'">'.t('mypassword_title').'</a></li>';
			echo '<li><a href="'.$root.'?logout=now">'.t('logout').'</a></li>';
		echo '</ul>';
	echo '</fieldset>';
	if (isAllowed('root_access')){
		echo '<p>'.t('back_root').' '.t('click').' <a href="'.$root.'?admin=root'.$ukey.'">';
		echo t('here').'</a></p><br />';
	} echo '</div>';
}

// ADMIN CENTER
function admin_center() { global $get;
	if (LOGGED) {
		$admin = isset($get['admin']) ? $get['admin'] : '';
		$action = isset($get['action']) ? $get['action'] : '';
		$tid = isset($get['tid']) ? $get['tid'] : null;
		$tks = isset($get['tks']) ? $get['tks'] : '';
		$admin_msg = isAllowed('comments_access') && isAllowed('admin_messages') ? true : false;
		$block_msg = isAllowed('comments_access') && isAllowed('admin_messages') && isAllowed('block_messages') ? 
			true : false;
		$spam_msg = isAllowed('comments_access') && isAllowed('admin_messages') && isAllowed('spam_messages') ? 
			true : false;
		$archive_msg = isAllowed('comments_access') && isAllowed('admin_messages') && isAllowed('archive_messages') ? 
			true : false;
		if (empty($admin) || (isset($get['ukey']) && $get['ukey'] != load_value('user_ks'))) {set_error(); return;}
		echo '<div class="ebook_admin">';
		switch ($admin) {
			case 'personal_data': personal_data(); break;
			case 'myfirsttime': admin_myfirsttime(); break;
			case 'myprofile': admin_myprofile(); break;
			case 'mypassword': admin_mypassword(); break;
			case 'root': user_root(); break;
			case 'bigroot': if (isAllowed('bigroot_access')){admin_bigroot();} else {set_error('401');} break;
			case 'config': if (isAllowed('config_access')){admin_config();} else {set_error('401');} break;
			case 'langs': if (isAllowed('lang_access') ){admin_langs();} else {set_error('401');} break;
			case 'asections': 
				if (isAllowed('section_access') || check_rights('sections', $tid, $tks, 'admin_by', 1)){
					admin_sections('asections', $action, false);}
				else {set_error('401');} break;
			case 'sections': 
				if (isAllowed('section_access') || check_rights('sections', $tid, $tks, 'admin_by', 1)){
				 	admin_sections('sections', $action);}
				else {set_error('401');} break;
			case 'users': if (isAllowed('users_access')) {admin_users();} else {set_error('401');} break;
			case 'iplugins': 
				if (isAllowed('plugins_install')) {admin_iplugins($action);} else {set_error('401');} break;
			case 'plugins': if (isAllowed('plugins_access')) {admin_plugins($action);} else {set_error('401');} break;
			case 'pages': 
				if (isAllowed('page_list') || check_rights('pages', $tid, $tks, 'admin_by', $action) || 
					verify_admin('pages', $tid)) {admin_pages('pages', 0);} else {set_error('401');} break;
			case 'cpages': 
				if (isAllowed('page_list') || verify_admin('cpages', $tid)){admin_pages('cpages', 0);} 
				else {set_error('401');} break;
			case 'comments': if (isAllowed('comments_access')) {cpanel_comments();} else {set_error('401');} break;
			case 'comment': if ($admin_msg) {admin_comments('comment', 'comment', 0);} else {set_error('401');} break;
			case 'comok': if ($admin_msg) {admin_comments('comok', 'comok', 1);} else {set_error('401');} break;
			case 'comwap': if ($admin_msg) {admin_comments('comwap', 'comwap', 2);} else {set_error('401');} break;
			case 'comspam': 
				if ($spam_msg) {admin_comments('comspam', 'comspam', 3, 'spam_messages');} 
				else {set_error('401');} break;
			case 'combku': 
				if ($block_msg) {admin_comments('combku', 'combku', 4, 'block_messages');} 
				else {set_error('401');} break;
			case 'combke': 
				if ($block_msg) {admin_comments('combke', 'combke', 5, 'block_messages');} 
				else {set_error('401');} break;
			case 'comarch': 
				if ($archive_msg) {admin_comments('comarch', 'comarch', 6, 'archive_messages');} 
				else {set_error('401');} break;
			case 'comrep': 
				if ($spam_msg) {admin_comments('comrep', 'comrep', 7, 'spam_messages');} 
					else {set_error('401');} break;
			default :
				$plugin = retrieve_mysql('plugins', 'sef_file', '"'.$admin.'"', 'id,admin_by', " AND installed = 1");
				if ($plugin && isGroupAllowed($plugin)) {call_user_func_array('admin_'.$admin, array($action));}
				else {set_error();}
		} echo '</div>';
	} else {set_error();}
}

?>