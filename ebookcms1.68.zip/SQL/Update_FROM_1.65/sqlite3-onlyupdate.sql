-- ---------------------------------------------------------------------------
--
--					ebookcms Update sQlite (FROM 1.65) - All rights reserved
--					Copyright (c) 2015 by Rui Mendes
--					Revision: 0 
--
-- ---------------------------------------------------------------------------

-- UPDATE core_version
UPDATE [config] SET [field] = 'core_version', value = 'ebookcms_1.68' WHERE id = 1;
