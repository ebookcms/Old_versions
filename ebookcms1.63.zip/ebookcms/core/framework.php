<?php

if (!defined('SECURE_ID') && SECURE_ID == '1234') {die('ACCESS DENIED');}

# **************************************************************************************************************
# --------------------------------------------------------------------------------------------------------------
# **************************************************************************************************************
#
#							Application Programming Interface eBookCMS
#							Version for eBookCMS 1.63
#							Revision : 0
#							Stable Release date: January 20, 2014
#							Copyright (c) by Rui Mendes
#							API eBookCMS is licensed under a "Creative Commons License"
#
# **************************************************************************************************************
# --------------------------------------------------------------------------------------------------------------
# **************************************************************************************************************

// CHECK RIGHTS
function check_rights($table, $id, $tks, $field, $action, $option = 0) { global $get;
	if (!isset($id) && $action == 'new') {return false;}
	$uid = load_value('user_id');
	$gm = load_value('user_gm'); if (strlen($gm) == 1) {$gx = '0'.$gm;}
	if ($action == 'save'){
		if (isset($_POST['id'])){$id = clean($_POST['id']); $id = decryptRSA($id);}
		if (isset($_POST) && isset($_POST['tks'])) {$tks = clean($_POST[encryptRSA('tks')]);}
		else if (isset($get['tks'])) {$tks = $get['tks'];}
	}
	$tks = $action != 'new' ? decryptRSA($tks) : "";
	$ext = $action != 'new' ? " AND key_security = '$tks'" : "";
	$id = $action == 'new' ? decryptRSA($id) : $id;
	if ($table == 'pages' && $id && $action != 'new'){
		$hdata = retrieve_mysql($table, "id", $id, 'ptype,section_id'," AND key_security = '$tks'");
		if (!$hdata) {return false;}
		$id = $hdata['section_id']; $ext = '';
		$table = $hdata['ptype'] == 'sections'; unset($hdata);
	}
	$data = retrieve_mysql($table, "id", $id, $field, $ext);
	$list = explode(',', $data[$field]);
	$allowed = in_array($gm, $list) || ($option == 1 && in_array('00', $list)) || $gm == 1 ? true : false;
	unset($data); return $allowed;
}

// VERIFY RIGHTS
function verify_admin($table, $id, $type = 0){ global $get; $hereited = false;
	if (isset($_POST['id'])) {$id = decryptRSA(clean($_POST['id']));}
	switch ($table) {
		case 'pages': case 'cpages': $hereited = true;
			if (isset($get['action']) && $get['action'] != 'new'){
				$hdata = retrieve_mysql('pages', "id", $id, "ptype,section_id", "");
				if ($hdata['section_id']) {$id = $hdata['section_id'];} unset($hdata);
			} else {$id = decryptRSA($id);}
			$table = 'sections';	break;
	}
	$data = retrieve_mysql($table, "id", $id, "admin_by,only_author","");
	if ($data && isGroupAllowed($data)) {$hereited = true;}
	return $hereited;
}

// FILTER BY
function table_filterBy($form, $func){ global $get, $uri;
	if (isset($form[$func])) { echo '<p>';
		$root = getInfo('ROOT').getPHPName();
		$pn = !empty($get['pn']) ? '&amp;pn='.$get['pn'] : '';
		$ukey = $get && isset($get['ukey']) ? '&amp;ukey='.$_SESSION[HURI][encryptRSA('user_security')] : '';
		$filter = explode(',', $form[$func]);
		$all = isset($filter[5]) ? t($filter[5]) : t('all');
		$list = explode(',', t($filter[4]));
		$link  = $root.'?'.$uri[0].'='.$get[$uri[0]];
		$link .= isset($get['action']) ? '&amp;action='.$get['action'] : '';
		$filter0 = isset($get[$filter[2]]) ? ' <a href="'.$link.$ukey.'">'.$all.'</a>' : $all;
		echo '<b>'.t($filter[3]).'</b>: '.$filter0;
		$query  = "SELECT DISTINCT (".$filter[1].") FROM ".PREFIX.$filter[0];
		$query .= isset($filter[6]) ? " WHERE ".$filter[5] : "";
		if ($result = db() -> query($query)){
			while($r = dbfetch($result, false)){
				if (isset($get[$filter[2]]) && $get[$filter[2]] == $r[$filter[1]]) {
					echo ' - '.$list[$r[$filter[1]]];
				} else {
					echo ' - <a href="'.$link.'&amp;'.$filter[2].'='.$r[$filter[1]].$pn.$ukey.'">';
					echo $list[$r[$filter[1]]].'</a>';
				}
			} unset($result);
		} echo '</p>';
	}
}

// CORRECT URL
function fixUrl($url){
	if (HTACCESS){
		$url = preg_replace("#(\?page\=)(\w+?)#siU", "page/$2/", $url);
	} return $url;
}


// GENERATE SEF TITLE
function genSEF($string) {
	foreach (t('special_chars') as $key => $value) {$string = preg_replace('/'.$key.'/', $value, $string);}
	$string = str_replace(' ', '-', $string);
	$string = preg_replace('/[^0-9a-zA-Z-_]/', '', $string);
	$string = str_replace('-', ' ', $string);
	$string = preg_replace('/^\s+|\s+$/', '', $string);
	$string = preg_replace('/\s+/', ' ', $string);
	$string = str_replace(' ', '-', $string);
	return strtolower($string);
}

// LOAD ADMIN IMAGES
function load_icon($var) {
	switch($var) {
		case 'img_edit' : $img = 'edit.png'; break;
		case 'img_browse' : $img = 'folder.png'; break;
		case 'img_admin' : $img = 'browse.png'; break;
		case 'img_install' : $img = 'install.png'; break;
		case 'img_clean' : $img = 'clean.png'; break;
		case 'img_pages' : $img = 'pages.png'; break;
		case 'img_delete' : $img = 'delete.png'; break;
		case 'img_noaccessd' : $img = 'noaccess.png'; break;
		case 'img_up': $img = 'up.png'; break;
		case 'img_minus': $img = 'minus.png'; break;
		case 'img_down': $img = 'down.png'; break;
		case 'img_upload' : $img = 'upload.png'; break;
		case 'img_exclamation' : $img = 'exclamation.png'; break;
	} return 'js/ebookcms/'.$img;
}

// RETURN ARRAY LIST
function getDataArray($table, $where, $id, $field, $delete, $recall){
	$where1 = !empty($where) ? " WHERE ".$where.';' : ';';
	$where1 = str_replace('%id', $id, $where1);
	$sql = "SELECT id, $field FROM ".PREFIX.$table.$where1;
	if ($res1 = db() -> query($sql)){
		while ($r = dbfetch($res1)) {
			$key = $r[$field];
			$delete[$key] .= empty($delete[$key]) ? $r['id'] : ','.$r['id'];
			if (isset($recall[$key]) && $recall[$key] == 'true') {
				$delete = getDataArray($table, $where, $r['id'], $field, $delete, $recall);
			}
		} unset($res1);
	} return $delete;
}

// DELETE HERITED DATA
function delete_herited($table, $where, $id, $field, $commands, $herited = '') { global $get;
	if ($get['action'] != 'delete') {return;}
	$where1 = !empty($where) ? " WHERE ".$where.';' : ';';
	$where1 = str_replace('%id', $id, $where1);
	if (isset($field) && !empty($field) && isset($commands) && !empty($commands)){
		$lcontrol = explode('|', $commands);
		for ($i = 0; $i < count($lcontrol); $i++){
			$key = substr($lcontrol[$i], 0, strpos($lcontrol[$i], '@'));
			$control[$key] = substr($lcontrol[$i], strpos($lcontrol[$i], '@')+1);
			$xcontrol[$key] = substr($lcontrol[$i], strrpos($lcontrol[$i], '@')+1);
			$delete[$key] = empty($herited) ? '' : $herited[$key];
		}
		$delete = getDataArray($table, $where, $id, $field, $delete, $xcontrol);
		foreach ($control as $key => $value) {
			$mlist = explode(',', $delete[$key]);
			$mcontrol = explode('@', $value); $sqx = '';
			for ($i=0; $i < count($mlist); $i++){
				$sqx .= $i == 0 ? '('.$mcontrol[1].' = '.$mlist[$i] : ' OR '.$mcontrol[1].' = '.$mlist[$i];
			} $sqx .= ')';
			$mcontrol[2] = str_replace('%content', $sqx, $mcontrol[2]);
			$qw1 = "DELETE FROM ".PREFIX.$mcontrol[0];
			if (!empty($mcontrol[2])) {$qw1 .= " WHERE ".$mcontrol[2].';';}
			if ($res2 = db() -> query($qw1)) {$rr = dbfetch($res1);}
		}
	}
	$query = "DELETE FROM ".PREFIX.$table.$where1;
	if ($result = db() -> query($query)) {$r = dbfetch($result);}
	unset($result);
}

// GENERATE TAGS FROM TEXT
function generateTags($text, $leng = 5){
	$text = strtolower($text);
	$records = array_count_values(str_word_count($text, 1)); $count = 0;
	$list = array(); $max = 1; $tags = ''; $total = 0; $miss = 0;
	foreach($records as $key => $record) {
        if (intval($record) > 1  && strlen($key)>3) {
			$result[$key] = $record;
			if (empty($list['txt'][$record])) {
			 	$list['txt'][strtolower($record)] = $key;
				$list['count'][$record] = 1;}
			else {$list['txt'][$record] .= ','.$key; $list['count'][$record]++;}
			if ($max < $record) {$max = $record;}
			$count++;
		}
    }
    for ($i = $max; $i>0; $i--){
    	$num = !empty($list['count'][$i]) ? $list['count'][$i] : 0;
		if ($total + $num < $leng){
			if (!empty($list['txt'][$i])){$tags = empty($tags) ? $list['txt'][$i] : $tags.','.$list['txt'][$i];}
			$total = $total + $num;
		} else {
			$miss = $leng - $total;
			$sub = explode(',',$list['txt'][$i]);
			for ($j=0; $j<$miss; $j++){$tags .= ','.$sub[$j];}
			break;
		}
	} unset($list, $sub);
	return $tags;
}

// FORMS
function create_form($form) { global $get, $uri, $last, $lget, $luri, $t;
# **************************************************************************************************************
# --------------------------------------------------------------------------------------------------------------
#
# 									C  O  M  M  O  N
#
# --------------------------------------------------------------------------------------------------------------
# **************************************************************************************************************
	$action = clean($get['action']);
	$taction = isset($form['taction']) ? $form['taction'] : $form['action'];
	$uid = load_value('user_id'); $lang_id = load_value('lang');
	$ukey = $get && isset($get['ukey']) ? '&amp;ukey='.$_SESSION[HURI][encryptRSA('user_security')] : '';
	$xukey = $get && isset($get['ukey']) ? '&ukey='.$_SESSION[HURI][encryptRSA('user_security')] : '';
	if (!empty($lang_id) && $lang_id != 1) {$lang = '&amp;lang='.$lang_id;} else {$lang = '';}
	$root = getInfo('ROOT').getPHPName();
	$title = isset($form['title']) ? t($form['title']) : t($taction.'_title');
	$title = !empty($title) ? '<h1 class="h1_title">'.$title.'</h1>' : '';
	if ($uri[0] != 'admin'){
		$plugin = retrieve_mysql("plugins", "sef_file", '"'.$uri[0].'"', "id"," AND auto_load = 1 AND installed = 1");
		if (!$plugin) {echo '<meta http-equiv="refresh" content="0; url='.getInfo('ROOT').'?error=404">'; return;}
		$uadmin = $uri[0]; $gadmin = 'admin';
	} else {$uadmin = 'admin'; $gadmin = $form['action'];}
	$tb = isset($get['tb']) ? '&amp;tb='.$get['tb'] : '';
	$here = '<a href="'.$root.'?'.$uadmin.'='.$gadmin.'&amp;action=new'.$tb.$lang.$ukey.'">'.t('here').'</a>';
	$subtitle1 = $action == 'list' && isset($form['subtitle1']) && isset($form['edit_rights']) && 
	$form['edit_rights'] == 1 ? str_replace('$here', $here, $form['subtitle1']) : '';
	$subtitle = !empty($subtitle1) ? '<h3>'.$subtitle1.'</h3>' : '';
	if (!empty($title) || !empty($subtitle)){
		if (HTML5 && !empty($subtitle1)) {echo '<header>'; if (!empty($subtitle1)) {echo '<hgroup>';}}
		if ($action != 'content') {echo $title.$subtitle1;}
		if (HTML5 && !empty($subtitle1)) {echo '</hgroup>';}
		if ($action != 'moveup' && $action != 'movedown') {
			$txt1 = in_array($taction.'_'.$action, $t) ? t($taction.'_'.$action) : '';
			$txt1 = str_replace('$here', $here, $txt1);
			if (!empty($txt1) && isset($form['subtitle2']) && $action == 'list') {echo '<p>'.$txt1.'</p>';}
		}
		if (HTML5 && !empty($subtitle1)) {echo '</header>';}
		if (($uri[0] == 'admin' && $get['admin'] != $form['action']) || !isset($get['ukey']) ||	(isset($get['ukey']) 
		&& decryptRSA($get['ukey']) != decryptRSA($_SESSION[HURI][encryptRSA('user_security')]))) {
			echo '<meta http-equiv="refresh" content="0; url='.getInfo('ROOT').'?error=404">'; return;
		}
	}
	# BACK VARIABLES
	$back_admin = ''; $back_action = ''; $back_tks = ''; $back_tid = ''; $back_other = '';
	$back_to = isset($form['back_to']) ? explode(',', $form['back_to']) : false;
	$back_id = isset($form['back_id']) ? explode(',', $form['back_id']) : false;
	$back_sid = isset($form['back_sid']) ? explode(',', $form['back_sid']) : false;
	# SAVE AND CANCEL
	if ($action == 'save') {
		$fp = isset($_POST['fp']) ? clean($_POST['fp']) : ''; $fp = decryptRSA($fp);
		$fg = isset($_POST['fg']) ? clean($_POST['fg']) : '';
		$pn = isset($_POST['pn']) ? clean($_POST['pn']) : '';
		$gm = isset($_POST['gm']) ? clean($_POST['gm']) : '';
		$lget = explode(',', clean($_POST[encryptRSA('get')]));
		$luri = explode(',', clean($_POST[encryptRSA('uri')]));
		if (isset($lget)) {for ($i=0; $i < count($luri); $i++) {$last[$luri[$i]] = isset($lget[$i]) ? $lget[$i]: '';}}
	} else {
		$fp = isset($get['fp']) ? $get['fp'] : '';
		$fg = isset($get['fg']) ? $get['fg'] : '';
		$pn = isset($get['pn']) ? $get['pn'] : '';
		$gm = isset($get['gm']) ? $get['gm'] : '';
	}
	$fpp = !empty($fp) ? '&amp;fp='.$fp : ''; $fgg = !empty($fg) ? '&amp;fg='.$fg : '';
	$gmm = !empty($gm) ? '&amp;gm='.$gm : ''; $pnn = !empty($pn) ? '&amp;pn='.$pn : '';
	$back_other = $fpp.$fgg.$pnn.$gmm.$lang;
	if (isset($form['back_id']) || isset($form['back_sid'])) {
		$back_admin = $back_sid[0]; $back_action = $back_sid[1];
	} else { $back_admin = $get['admin']; $back_action = 'list';}
	if ((isset($_POST['id']) && isset($back_id)) || $action=='delete') {
		$id = $action=='delete' ? $get['tid'] : decryptRSA(clean($_POST['id']));
		$data = retrieve_mysql($back_id[0], $back_id[1], $id, '*', '');
		$sid = isset($data[$back_sid[2]]) ? clean($data[$back_sid[2]]) : false;
	} else {$sid = isset($_POST[$back_sid[2]]) ? decryptRSA(clean($_POST[$back_sid[2]])) : false;}
	$back_tid = isset($sid) && $sid != 0 ? '&amp;tid='.$sid : '';
	if (isset($form['back_sid'])) {
		$hdata = retrieve_mysql($back_sid[0], 'id', $sid, '*', '');
		if ($hdata) {$back_tks = '&amp;tks='.encryptRSA($hdata[$form['edit_ks']], false);}
	}
	if ($fp != 0 && isset($data['seftitle'])) {
		if ($fp == 1) {$link = $root;}
		if ($fp == 2) {$link = $root.'?page='.$data['seftitle'];}
		if ($fp == 3) {$link = $root.'?admin=root&amp;fp=3'.$ukey;}
	} else {
		# LAST PAGE WAS A PLUGIN
	 	if (isset($form['back_to']) && $action == 'save' && $fp == 4) {
			$comment = retrieve_mysql('comments', 'id', $id, 'ptype,plug_id,pcontent_id', '');
			if (isset($comment['ptype']) && $comment['ptype'] == 1 && isset($comment['plug_id'])) {
				$plugin = retrieve_mysql('plugins', 'id', $comment['plug_id'], 'id,sef_file,install_table', '');
				if ($plugin) {
					$vkey = retrieve_mysql($plugin['install_table'], 'id', $comment['pcontent_id'], 'vkey', '');
					$link = defined('HTACCESS') && HTACCESS == true ? $root: $root.'?';
					$link.= pre_seao($plugin['sef_file'], 'view').pre_seao('action', 'comments');
					$link.= pre_seao('tid', $comment['pcontent_id']);
					$link.= pre_seao('vkey', encryptRSA($vkey['vkey'], false));
				}
			}
		} else
		if (isset($form['back_to']) && $action == 'save') {
			$link = $root.'?admin='.$back_to[0];
			if (isset($back_to[1])) {$link .= '&amp;action='.$back_to[1];}
			$link .= $fpp.$ukey;
		} else {
			$link = $root.'?admin='.$back_admin.'&amp;action='.$back_action.$back_tid.$back_tks.$back_other.$ukey;
		}
	}

# **************************************************************************************************************
# --------------------------------------------------------------------------------------------------------------
#
# 									C  A  N  C  E  L
#
# --------------------------------------------------------------------------------------------------------------
# **************************************************************************************************************

	if ($_POST && isset($_POST[encryptRSA('cancel')])) {
		echo '<div class="msginfo"><p>'.t('back_content').'</p></div>';
		echo '<meta http-equiv="refresh" content="1; url='.fixUrl($link).'">'; return;
	} else

# **************************************************************************************************************
# --------------------------------------------------------------------------------------------------------------
#
# 									S   A   V   E
#
# --------------------------------------------------------------------------------------------------------------
# **************************************************************************************************************

	if (($_POST && isset($_POST[encryptRSA('submit')])) || (isset($_POST['adm']) && $_POST['adm'] == 'config')) {
		$id = isset($_POST['id']) ? clean($_POST['id']) : 0; $id = decryptRSA($id); $btid = '';
		$uid = isset($_POST['id']) && $get['admin'] != 'myprofile' && $get['admin'] != 'mypassword' ? 
			'&amp;tid='.$id : '';
		if (isset($_POST[encryptRSA('tks')])) {
			$tks = clean($_POST[encryptRSA('tks')]); $tks = decryptRSA($tks);
		} elseif (isset($get['tks'])) {$uid .= '&amp;tks='.encryptRSA($tks, false);}
		$tb = isset($_POST['tb']) ? '&amp;tb='.clean($_POST['tb']) : '';
		$last_action = clean($_POST[encryptRSA('last_action')]); $last_action = decryptRSA($last_action);
		$reserved = ''; $duplicated = ''; $must_redirect = false;
		$parent = isset($_POST['parent']) ? clean($_POST['parent']) : null;
		// VERIFY FIELDS AND PREPARE THEM INTO ARRAY
		for ($i=0; $i<count($form['fields']); $i++) {
			$field = explode(',', $form['fields'][$i]);
			switch ($field[0]) {
				case 'input_text': case 'input_dtext': case 'input_ntext': case 'input_xtext' : 
				case 'input_float' : case 'input_tags' : case 'input_int':
					$inputText = isset($_POST[encryptRSA($field[1])]) ? clean($_POST[encryptRSA($field[1])]) : '';
					if ($field[0] == 'input_ntext') {
						if ($last_action == 'new' && $field[4] == 'true' && empty($inputText)){
							$reserved .= ','.$field[2];}
						if (!empty($inputText)) {$save_fields[$field[1]] = encryptRSA($inputText,false);}
					} else {
						if ($field[0] == 'input_float') {$inputText = is_float(floatval($inputText)) ? 
							floatval($inputText) : 0.0;}
						if ($field[0] == 'input_int') {$inputText = is_int(intval($inputText)) ? 
							intval($inputText) : 0;}
						if ($field[0] == 'input_dtext') {$inputText = encryptRSA($inputText, false);}
						if ($field[0] == 'input_tags' && empty($inputText)) {
							if (isset($save_fields['texto1'])){
								$inputText = isset($save_fields['texto1']) ?
									generateTags($save_fields['texto1']) : $inputText;
							} else if (isset($save_fields['texto2'])) {
								$inputText = isset($save_fields['texto2']) ?
									generateTags($save_fields['texto2']) : $inputText;
							}
						}
						if ($field[4] == 'true' && empty($inputText)) {$reserved .= ','.$field[2];}
						$save_fields[$field[1]] = $inputText;
					} $param_field[$field[1]] = 's'; break;
				case 'input_password':
					$inputText = $_POST[encryptRSA($field[1])];
					if ($field[4] == 'true' && empty($inputText)) {$reserved .= ','.$field[1];}
					$save_fields[$field[1]] = md5($inputText); 
					$param_field[$field[1]] = 's'; break;
				case 'input_password1': case 'input_password2': case 'input_password3':
					$inputText = $_POST[encryptRSA($field[1])];
					if ($field[4] == 'true' && empty($inputText)) {$reserved .= ','.$field[1];}
					break;
				case 'create_password':
					$inputText = isset($_POST[encryptRSA($field[1])]) ? $_POST[encryptRSA($field[1])] : '';
					if (!empty($inputText)) {$save_fields[$field[1]] = md5($inputText); $param_field[$field[1]] = 's';}
				break;
				case 'checkboxscrip': case 'checkbox': 
					$save_fields[$field[1]] = isset($_POST[$field[1]]) ? 1 : 0;
					$param_field[$field[1]] = 'i'; break;
				case 'combotable':
					$value = clean($_POST[$field[1]]);
					if ($field[4] == 'true' && (empty($value)|| $value == 0)) {$reserved .= ','.$field[2].'1';}
					$save_fields[$field[1]] = $value; $param_field[$field[1]] = $field[11]; break;
				case 'combolist': case 'comboscript':
					$value = clean($_POST[$field[1]]);
					if ($field[4] == 'true' && (empty($value)|| $value == 0)) {$reserved .= ','.$field[2].'1';}
					$save_fields[$field[1]] = $value;
					$param_field[$field[1]] = isset($field[7]) ? $field[7] : 'i'; break;
				case 'comboimage':
					if (isset($_POST[$field[1]])){
						$value = clean($_POST[$field[1]]); $save_fields[$field[1]] = $value; 
						$param_field[$field[1]] = 's'; 
					} break;
				case 'text_code':
					$value = clean_mysql($_POST[$field[1]]); $save_fields[$field[1]] = $value;
					$param_field[$field[1]] = 's';
					break;
				case 'genSEF':
					$value = clean($_POST[encryptRSA($field[1])]);
					if (empty($save_fields[$field[1]])) {
						$save_fields[$field[1]] = genSEF($save_fields[$field[2]]);
						$reserved = str_replace(','.$field[1], '', $reserved);
					} else {$save_fields[$field[1]] = genSEF($value);}
					$param_field[$field[1]] = 's';
					break;
				case 'choose_date': case 'newfield_date':  case 'choose_datetime':
					$day = isset($_POST[$field[1].'_day']) ? $_POST[$field[1].'_day'] : date('d');
					$month = isset($_POST[$field[1].'_month']) ? $_POST[$field[1].'_month'] : date('m');
					$year = isset($_POST[$field[1].'_year']) ? $_POST[$field[1].'_year'] : date('Y');
					if ($field[0] != 'choose_date') {
						$hour = isset($_POST[$field[1].'_hour']) ? $_POST[$field[1].'_hour'] : date('H');
						$min = isset($_POST[$field[1].'_min']) ? $_POST[$field[1].'_min'] : date('i');
						if (strlen($day) == 1) {$day = '0'.$day;}
						if (strlen($month) == 1) {$month = '0'.$month;}
						if (strlen($hour) == 1) {$hour = '0'.$hour;}
						if (strlen($min) == 1) {$min = '0'.$min;}
						$newdate = $year.'-'.$month.'-'.$day.' '.$hour.':'.$min.':00';
					} else {$newdate = $year.'-'.$month.'-'.$day;}
					if ($field[0] == 'choose_date' || $field[0] == 'choose_datetime' ||
						($last_action == 'new' && $field[0] == 'newfield_date')) {
						$save_fields[$field[1]] = $newdate;}
					$param_field[$field[1]] = 's';
				break;
				case 'text_area': if (isset($field[1]) && isset($_POST['ebook'.$field[1]])) {
					$save_fields[$field[1]] = clean_mysql($_POST['ebook'.$field[1]], false); 
					$param_field[$field[1]] = 's';
				} break;
				case 'newfield': if ($last_action == 'new') {
					$save_fields[$field[1]] = str_replace('@',',', $field[2]); 
					$param_field[$field[1]] = isset($field[3]) ? $field[3] : 's' ;} break;
				case 'savefield': if ($action == 'save') {
					$save_fields[$field[1]] = $field[2]; $param_field[$field[1]] = $field[3];} break;
				case 'same_value': if ($field[1]=='avatar') {$_SESSION[HURI]['avatar'] = $save_fields[$field[2]];}
					$save_fields[$field[1]] = $save_fields[$field[2]]; $param_field[$field[1]] = 's'; break;
				case 'same_newvalue': if ($last_action == 'new') {
					$save_fields[$field[1]] = $save_fields[$field[2]]; $param_field[$field[1]] = $field[3];} break;
				case 'updatefield':  if ($last_action == 'edit' && isset($_POST[$field[1]])) {
					$value = clean($_POST[$field[1]]); $value = decryptRSA($value);
					$save_fields[$field[1]] = $value;
					$param_field[$field[1]] = 's';
				} break;
				case 'newhidden': if ($last_action == 'new') {
					$newvalue = decryptRSA(clean($_POST[$field[1]]));
					$save_fields[$field[1]] = $newvalue;
					$param_field[$field[1]] = $field[3];}  
					break;
				case 'redirect' :
					$redirect = isset($_POST[encryptRSA($field[1],false)]) ? 
						decryptRSA($_POST[encryptRSA($field[1],false)]) : null;
					if ($redirect) {$must_redirect = true;}
					break;
				case 'encryptRSA':
					$value = $save_fields[$field[2]];
					$save_fields[$field[1]] = encryptRSA($value, false); 
					$param_field[$field[1]] = 's'; break;
				case 'multichoice':
					$ilist = isset($field[3]) ? explode(',',t($field[3])): ''; $mlist = '';
					$sublist = isset($_POST[$field[1]]) ? clean($_POST[$field[1]]) : '';
					$newlist = isset($field[6]) ? str_replace('@', ',', $field[6]) : $sublist;
					$start = isset($field[5]) ? $field[5] : 0;
					if ($start !=0) {$mlist = '01';}
					for ($j = $start; $j < count($ilist); $j++){
						$xnum = $j>9 ? $j : '0'.$j;
						if (isset($_POST[$field[1].'_'.$j]) && $_POST[$field[1].'_'.$j] == 'on') {
							$mlist .= $mlist != '' ? ','.$xnum : $xnum;}
					}
					if (empty($mlist)) {$mlist = isset($data[$field[1]]) ? $data[$field[1]] : $newlist;}
					$save_fields[$field[1]] = $mlist; $param_field[$field[1]] = 's';
				break;
			}
		}
		# CHECK REQUIRED FIELDS
		if (!empty($reserved)) {
			$reserved = substr($reserved, 1); $list = explode(',',$reserved);
			$utks = $id != 0 ? '&amp;tks='.encryptRSA($tks,false) : '';
			$pd = isset($_POST['pd']) ? '&amp;pd='.clean($_POST['pd']) : '';
			echo '<div class="msgerror"><h3>'.t('required_fields').'</h3>';
			echo '<ul>';
			for ($j=0; $j<count($list); $j++) {echo '<li>'.t($list[$j]).'</li>';}
			echo '</ul></div>';
			$tid = isset($_POST['section_id']) ? '&amp;tid='.clean($_POST['section_id']) : '';
			$redirect = $root.'?'.$uadmin.'='.$gadmin.'&amp;action='.$last_action.$tid.$uid.$utks.$pd.$ukey.$pnn;
			echo '<meta http-equiv="refresh" content="3; url='.fixUrl($redirect).'">';
			for ($i=0; $i<count($form['fields']); $i++) {
				$field = explode(',', $form['fields'][$i]);
				switch ($field[0]) {
					case 'input_ntext': 
					if (isset($save_fields[$field[1]])) {
						$save_fields[$field[1]] = decryptRSA($save_fields[$field[1]]);
						$param_field[$field[1]] = 's';
					} break;
				}
			} $_SESSION[HURI]['tmp'] = isset($save_fields) ? $save_fields : '';	return;
		}
		# CHECK DUPLICATE FIELDS
		$no_duplicates = isset($form['noduplicates']) ? explode(',', $form['noduplicates']) : null; $list = '';
		if ($no_duplicates && $id == 0) {
			for ($i=0; $i<count($no_duplicates); $i++) {
				if (empty($save_fields[$no_duplicates[$i]])) {
					$nqwr = "SELECT ".$no_duplicates[$i]." FROM ".PREFIX.$form['query_table']." WHERE id = $id";
					if ($result = db() -> query($nqwr)) {$qnqwr = dbfetch($result); unset($result);}
					$name = decryptRSA($qnqwr[$no_duplicates[$i]]); unset($qnqwr);
					$where1 = $no_duplicates[$i]." = '".$name."'";
				} else {$where1 = $no_duplicates[$i]." = '".$save_fields[$no_duplicates[$i]]."'";}
				if (is_numeric($id)) {$where1 = empty($where1) ? " id <> '$id'" : $where1." AND id <> '$id'";}
				$qwr = "SELECT id FROM ".PREFIX.$form['query_table']." WHERE ".$where1;
				if ($result = db() -> query($qwr)) {$ddata = dbfetch($result); unset($result);}
				if ($ddata) {$duplicated .= ','.$no_duplicates[$i];}
			}
		}
		if (!empty($duplicated)) {
			$btid = isset($_POST['section_id']) ? '&amp;tid='.clean($_POST['section_id']) : '';
			$duplicated = substr($duplicated, 1);
			$list = explode(',', $duplicated);
			echo '<div class="msgerror"><h3>'.t('duplicated_fields').'</h3>';
			echo '<ul>';
			for ($j=0; $j<count($list); $j++) {echo '<li>'.t($list[$j]).'</li>';}
			echo '</ul></div>';
			if ($last_action == 'new') {$uid = '';}
			$redirect = $root.'?'.$uadmin.'='.$gadmin.'&amp;action='.$last_action.$btid.$uid.$ukey.$pnn;
			echo '<meta http-equiv="refresh" content="3; url='.fixUrl($redirect).'">';
			for ($i=0; $i<count($form['fields']); $i++) {
				$field = explode(',', $form['fields'][$i]);
				switch ($field[0]) {
					case 'input_ntext': $save_fields[$field[1]] = decryptRSA($save_fields[$field[1]]); break;
				}
			} $_SESSION[HURI]['tmp'] = isset($save_fields) ? $save_fields : ''; return;
		}
		# CHANGE YOUR PASSWORD
		if (isset($form['change_password'])) {
			$id = $form['myprofile_id'];
			$pass = explode(',',$form['change_password']);
			$pass1 = $inputText = md5($_POST[encryptRSA($pass[1])]);
			$pass2 = $inputText = $_POST[encryptRSA($pass[2])];
			$pass3 = $inputText = $_POST[encryptRSA($pass[3])];
			$qp = "SELECT password FROM ".PREFIX.$form['query_table']." WHERE id = ? AND password = ?";
			if ($result = db() -> prepare($qp)) {
				$result = dbbind($result, array($id, $pass1), 'is');
			 	$vpass = dbfetch($result); unset($result);
			}
			if ($vpass && $pass1 != md5($pass2) && $pass2 == $pass3 && strlen($pass2)>3) {
				$save_fields[$pass[0]] = md5($pass2); $param_field[$pass[0]] = 's';
			} else {
				if (!$vpass) {echo '<div class="msgerror"><h3>'.t('wrong_password').'</h3></div>';}
				else if ($vpass && $pass1 == md5($pass2)) {
					echo '<div class = "msgerror"><h3>'.t('same_password').'</h3></div>';'';
				} else {echo '<div class = "msgerror"><h3>'.t('pass_notmatch').'</h3></div>';}
				$redirect = $root.'?'.$uadmin.'='.$gadmin.'&amp;action='.$last_action.$btid.$uid.$ukey.$pnn;
				echo '<meta http-equiv="refresh" content="3; url='.fixUrl($redirect).'">';
				return;
			}
		}
		# CREATE NEW KEYS
		if (isset($form['keys'])) {
			$keys = explode(',',$form['keys']);
			for ($i=0; $i<count($keys); $i++) {
				$newkey = genKey($keys[$i]);
			 	$save_fields[$keys[$i]] = $newkey;
				$param_field[$keys[$i]] = 's';
			}
		}
		# GET MAX ID FOR order_content
		if ($last_action == 'new' && isset($form['order'])) {
			$order_where = isset($form['order_where']) ? ' '.$form['order_where'] : '';
			$ord_list = isset($form['order_fields']) ? explode(',', $form['order_fields']) : '';
			if (!empty($ord_list)) {
				for ($k=0; $k < count($ord_list); $k++) {
					$ord = explode('@', $ord_list[$k]);
					$vord = isset($_POST[$ord[0]]) ? decryptRSA($_POST[$ord[0]]) : '';
					$order_where = str_replace($ord[1], $vord, $order_where);
				}
			}
			$qwr = "SELECT count(".$form['table_order'].") AS total from ".PREFIX.$form['query_table'].$order_where;
			$lang_id = isset($save_fields['lang_id']) ? $save_fields['lang_id'] : $lang_id;
			if ($lang_id != 1 || isset($get['lang'])) {$lang = '&amp;lang='.$lang_id;} else {$lang = '';}
			$language = !empty($lang_id) ? ' AND lang_id='.$lang_id : '';
			$qwr = str_replace('%lang_id', $language, $qwr);
			if ($result = db() -> query($qwr)) {$sql = dbfetch($result); unset($result);}
			$save_fields['order_content'] = $sql['total']+1; unset($sql); $param_field['order_content'] = 'i';
		} $params = '';
		# NEXT INSERT OR UPDATE
			if ($last_action == 'edit') {
				while (list($key, $value) = each($save_fields)) {
					if (empty($a)) {$a = $key.'=?'; $b = array($value);} else {$a .= ', '.$key.'=?'; $b[] = $value;}
					$params .= isset($param_field[$key]) ? $param_field[$key] : '';
				} $b[] = $id; $params .= 'i';
				$query = "UPDATE ".PREFIX.$form['query_table']." SET ".$a." WHERE id = ?;";
				if ($sql = db() -> prepare($query)) {
					$sql = dbbind($sql, $b, $params);
				}
			} elseif ($last_action == 'new') {
				while (list($key, $value) = each($save_fields)) {
					if (empty($a)) {$a = $key; $b = '?';} else {$a .= ','.$key; $b .= ',?';}
					$c[] = $save_fields[$key]; 
					$params .= isset($param_field[$key]) ? $param_field[$key] : '';
				}
				$query = "INSERT INTO ".PREFIX.$form['query_table']." (".$a.") VALUES (".$b.");";
				if ($sql = db() -> prepare($query)){
					$sql = dbbind($sql, $c, $params);
				} unset($sql);
				$qwr = "SELECT max(id) AS total from ".PREFIX.$form['query_table'];
				if ($rx = db() -> query($qwr)) {$msq = dbfetch($rx); unset($rx);}
				$id = $msq['total'];
			} unset($_SESSION[HURI]['tmp']);
		echo '<div class="msgsuccess"><p>'.t('update_sucess').'</p></div>';
		if ($parent) {echo '<meta http-equiv="refresh" content="1; url='.$root.'?page='.$parent.$pnn.'">'; return;}
		echo '<meta http-equiv="refresh" content="1; url='.fixUrl($link).'">';
		return;
	} else

# **************************************************************************************************************
# --------------------------------------------------------------------------------------------------------------
#
# 									E  D  I  T
#
# --------------------------------------------------------------------------------------------------------------
# **************************************************************************************************************

	if ($action == 'edit' || $action == 'new') { echo chr(13);
		$tid = $get && isset($get['tid']) ? clean($get['tid']) : '0';
		if (isset($gadmin) && ($gadmin == 'myprofile' || $gadmin == 'myfirsttime') && $form['myprofile_id']) {
			$id = $form['myprofile_id'];
		} else if (isset($form['key_id'])) {$id = $form['key_id'];}
		else if($action == 'edit' && $tid>0) {$id = $tid;}
		if (HTML5) {echo '<section>';}
		$formid = empty($form['form_id']) ? $gadmin : $form['form_id'];
		$enctype = !empty($form['enctype']) ? ' enctype="'.$form['enctype'].'"' : '';
		$charset = 'UTF-8';
		$query_fields = isset($form['query_fields']) ? $form['query_fields'] : '*';
		if (isset($id)) {
			$fks = isset($form['edit_ks']) ? $form['edit_ks'] : '';
			if (($gadmin == 'myprofile' || $gadmin == 'myfirsttime') && $form['myprofile_ukey']) {
				$tks = $form['myprofile_ukey'];}
			else {$tks = clean($get['tks']); $tks = decryptRSA($tks);}
			$query = "SELECT * FROM ".PREFIX.$form['query_table']." WHERE id = $id AND $fks = '$tks' LIMIT 1";
			if ($result = db() -> query($query)) {$data = dbfetch($result); unset($result);}
			if (!isset($data)) {echo '<div class="msgerror">'.t('wrong_key').'</div>'; return;}
		}
		# FORM
		$form_action = $root.'?'.$uadmin.'='.$gadmin.'&amp;action=save'.$ukey.$pnn; $rte = '';
		echo '<div class="ebform_edit">';
		echo '<form method="post" action="'.$form_action.'" id="ff'.$formid.'" class = "oforms" ';
		echo 'accept-charset="'.$charset.'" name="'.$formid.'"'.$enctype.'>';
		for ($i=0; $i<count($form['fields']); $i++) {
			$field = explode(',', $form['fields'][$i]);
			$fname = isset($field[1]) ? $field[1] : ''; $classname = isset($field[1]) ? "f".$field[1] : '';
			switch ($field[0]) {
				// **************
				// OPEN FIELDSET - 1-Name and "f"+ClassName; 2-Display legend name 3-Enable option Togle 
				// 4-Open(1) close(1)
				// **************
				case 'open_fieldset':
					$legend = $field[2] == '1' ? 
						'<legend class="eb_legend">'.ucfirst(t($fname)).'</legend><br />' : '';
					if ($field[3] == 0 || $field[2] == 0) {
						echo '<fieldset class="'.$classname.'">'.$legend; $display = '';
					} else {
						$display = $field[4] != '1' ? ' style="display: none;"' : '';
						echo '<fieldset class="'.$classname.'"><legend class="eb_legend">';
						echo '<a href="javascript:ftoggle(\''.$fname.'\');">';
						echo ucfirst(t($fname)).'</a></legend><br />';
					} echo '<div id="'.$fname.'"'.$display.'>'; break;
				// **************
				// CHECKBOX - 1-Field, Name 2-Text 3-Enable/Disable for new  4-false add <br>
				// **************	
				case 'checkbox' : case '_checkbox' :
					if (isset($_SESSION[HURI]['tmp'][$field[2]])) {$value = $_SESSION[HURI]['tmp'][$field[2]];}
					else if ($action == 'edit') {
						$value = isset($field[2]) && isset($data[$field[2]]) ? $data[$field[2]] : $field[2];
					} else {$value = $field[3];}
					$checked = $value ? ' checked' : '';
					echo '<input type="checkbox" name="'.$field[1].'" id="'.$field[1].'" value="'.$value.'"';
					echo $checked.'> ';
					echo '<label for="'.$field[1].'">'.t($field[2]).'</label><br />';
					if (isset($field[4]) && $field[4] != 'true') {echo '<br />';} break;
				// **************
				// COMBOTABLE - 1-Field, Name, id  2-Text   3-Table   4=True/False-Rquired but not index=0 
				//	5-indexes@values   6=sql(where)  7=index0 (0@all)  8=default for new   11-type data for mysqli
				// **************	
				case 'combotable':
					echo '<dl><dt><label for = "'.$field[2].'">'.t($field[2]).'</label></dt>';
					$qfields = str_replace('@', ',', $field[5]); $ffilds = explode('@', $field[5]);
					$fvalues = explode('AND ', $field[6]);
					for ($g=0; $g < count($fvalues); $g++) {
						$vvalue = preg_replace("#[\[](.*)[\]]#sU", "$1", $fvalues[$g]);
						$xval = explode('=', $vvalue);
						if (isset($xval[1]) && isset($data[$xval[1]])) {
							$fvalues[$g] = str_replace('['.$xval[1].']', $data[$xval[1]], $fvalues[$g]);
						}
					} $fvalues = implode('AND ', $fvalues);
					$dorder = str_replace('@',' AND ', $fvalues);
					$cdata = retrieve_mysql($field[3], '', '', $qfields, $dorder, '');
					if (isset($_SESSION[HURI]['tmp'][$field[2]]) && $_SESSION[HURI]['tmp'][$field[2]] == '0') {
						$selected = ' selected = "selected"';
					} else if ($action == 'new') {$selected = $field[8] == '0' ? ' selected = "selected"' : '';}
					else {$selected = isset($data[$ffilds[0]]) && $data[$ffilds[0]] == '0' ? 
						' selected = "selected"' : '';}
					echo '<dd><select name = "'.$field[1].'" id = "'.$field[2].'">';
					$toption = explode('@', $field[7]);
					if ($field[7]) {echo '<option value = "'.$toption[0].'"'.$selected.'>'.t($toption[1]).'</option>';}
					for ($j=0; $j < count($cdata); $j++) {
						$selected = '';
						$value1 = isset($field[9]) && $field[9] == 1 ? 
							decryptRSA($cdata[$j][$ffilds[1]]) : $cdata[$j][$ffilds[1]];
						$value2 = isset($cdata[$j][$field[10]]) ? $cdata[$j][$field[10]] : $cdata[$j][$ffilds[0]];
						if (isset($_SESSION[HURI]['tmp'][$field[2]]) && 
							$_SESSION[HURI]['tmp'][$field[2]] == $cdata[$j][$ffilds[0]]) {
							$selected = ' selected = "selected"';
						} else
						if ($action == 'new') {
							$selected = $field[8] == $cdata[$j][$ffilds[0]] ? ' selected = "selected"' : '';
						} else if (isset($data[$field[1]]) && $value2 == $data[$field[1]]) {
						 	$selected = ' selected = "selected"';
						} else {$selected = isset($data[$field[1]]) && $data[$field[1]] == $cdata[$j][$ffilds[0]] 
							? ' selected = "selected"' : '';
						} echo '<option value = "'.$value2.'"'.$selected.'>'.$value1.'</option>';
					}
					echo '</select></dd></dl><br />'; break;
				// **************
				// COMBOLIST - 1-Field, Name, id   2-Text   3-Stringlist   4=True/False-Rquired but not index=0 
				// 5-default
				// **************	
				case 'combolist':
					echo '<dl><dt><label for = "'.$field[2].'">'.t($field[2]).'</label></dt>';
					$qfields = explode(',', t($field[3]));
					if (isset($_SESSION[HURI]['tmp'][$field[1]])) {$value = $_SESSION[HURI]['tmp'][$field[1]];}
					else {$value = isset($data[$field[1]]) ? $data[$field[1]] : $field[5];}
					echo '<dd><select name = "'.$field[1].'" id = "'.$field[2].'">';
					for ($j=0; $j<count($qfields); $j++) {
						if (isset($field[6]) && $field[6] == 1) {
							$selected = $value == $qfields[$j] ? ' selected = "selected"' : '';
							echo '<option value = "'.$qfields[$j].'"'.$selected.'>'.$qfields[$j].'</option>';
						} else {
							$selected = $value == $j ? ' selected = "selected"' : '';
							if ($action == 'new') {$selected = $value == $j? ' selected = "selected"' : '';}
							echo '<option value = "'.$j.'"'.$selected.'>'.$qfields[$j].'</option>';
						}
					}
					echo '</select></dd></dl><br />'; break;
				case 'comboscript':
					echo '<dl><dt><label for = "'.$field[2].'">'.t($field[2]).'</label></dt>';
					$qfields = explode(',', t($field[3])); $name = $field[2]; $count = count($qfields);
					if (isset($_SESSION[HURI]['tmp'][$field[1]])) {$value = $_SESSION[HURI]['tmp'][$field[1]];}
					else {$value = isset($data[$field[1]]) ? $data[$field[1]] : $field[5];}
					echo '<dd><select name = "'.$field[1].'" id="'.$name.'"';
					echo ' onChange = "javascript:chooseplace(\''.$name.'\',\''.$count.'\');">';
					for ($j=0; $j<count($qfields); $j++) {
						if (isset($field[6]) && $field[6] == 1) {
							$selected = $value == $qfields[$j] ? ' selected = "selected"' : '';
							echo '<option value = "'.$qfields[$j].'"'.$selected.'>'.$qfields[$j].'</option>';
						} else {
							$selected = $value == $j ? ' selected = "selected"' : '';
							if ($action == 'new') {$selected = $value == $j? ' selected = "selected"' : '';}
							echo '<option value = "'.$j.'"'.$selected.'>'.$qfields[$j].'</option>';
						}
					} echo '</select></dd></dl><br />'; break;
				// **************
				// INPUTLIST - 1-Field, Name, id   2-Text   3-Stringlist   4-default  5-Use length=2
				// **************	
				case 'multichoice':
					echo '<fieldset><legend> '.ucfirst(t($field[1])).' </legend><br />';
					$nlist = isset($field[6]) ? explode('@',$field[6]) : '';
					$rlist = isset($get['action']) && $get['action'] != 'new' && isset($data) ? 
						explode(',',$data[$field[1]]) : $nlist;
					$ilist = isset($field[3]) ? explode(',',t($field[3])): '';
					$start = isset($field[5]) ? $field[5] : 0;
					for ($j=$start; $j<count($ilist); $j++){
						$checked = (is_array($rlist) && in_array($j, $rlist)) || ($action == 'new' && $field[4]==$j) ?
							' checked' : '';
						echo '<input type="checkbox" name="'.$field[1].'_'.$j.'" id="'.$field[1].'_'.$j.'"';
						echo $checked.'> <label for="'.$field[1].'_'.$j.'">'.$ilist[$j].'</label><br />';
					} echo '</fieldset><br />'; break;
				// **************
				// InputText - 1-FieldName  2-TextTitle  3-className  4-Required, 5-Size , 6-Maxlength, 
				// 7=default for new 8=return
				// **************	
				case 'input_text': case 'input_dtext': case 'input_rtext' : case 'input_ntext': 
				case 'input_drtext': case 'input_xtext': case 'input_float': case 'input_tags': case 'input_int':
					if ($field[0] == 'input_xtext' && empty($data[$field[2]])) {break;}
					if ($field[0] == 'input_ntext' && $action == 'edit') {break;}
					echo '<dl>';
					if ($action == 'new' && !isset($_SESSION[HURI]['tmp'])) {$value = isset($field[7]) ? 
						$field[7] : '';}
					else if (isset($_SESSION[HURI]['tmp']) || (isset($field[1]) && isset($data) && 
						isset($data[$field[1]]))) {
						$value = isset($_SESSION[HURI]['tmp'][$field[1]]) ? 
							$_SESSION[HURI]['tmp'][$field[1]] : (isset($data[$field[1]]) ? $data[$field[1]] : '');
					} else {$value = '';}
					if ($field[0] == 'input_dtext' || $field[0] == 'input_drtext') {$value = decryptRSA($value);}
					$charf = $field[4] == 'true' ? '* ' : '';
					$size = $field[6] ? ' size = "'.$field[5].'"' : '';
					$maxlength = $field[6] ? ' maxlength = "'.$field[6].'"' : '';
					$read_only = $field[0] == 'input_rtext' || $field[0] == 'input_drtext' ? 
						' readonly = "readonly"' : '';
					$txt = $field[0] == 'input_xtext' ? $data[$field[2]] : t($field[2]);
					echo '<dt><label for = "'.$fname.'">'.$charf.$txt.'</label></dt>';
					if (isset($field[8]) && $field[8] != 'true') {echo '<br />';}
					echo '<dd><input type = "text" name="'.encryptRSA($fname).'" id = "'.$fname.'"';
					echo ' value = "'.$value.'" ';
					echo 'class = "'.$field[3].'"'.$size.$maxlength.$read_only.'></dd>';
					echo '</dl><br />';
				break;
				// **************
				// InputPassword - 1-FieldName  2-TextTitle  3-className  4-Required, 5-Size , 
				// 6-Maxlength
				// **************	
				case 'input_password': case 'input_password1': case 'input_password2': 
				case 'input_password3': case 'create_password':
					$value = isset($field[7]) && $field[0] == 'create_password' ? $field[7] : '';
					$charf = $field[4] == 'true' ? '* ' : '';
					$size = $field[6] ? ' size = "'.$field[5].'"' : '';
					$maxlength = $field[6] ? ' maxlength = "'.$field[6].'"' : '';
					if ($field[0] == 'create_password' && $action == 'edit') {continue;}
					echo '<dt><label for = "'.$field[2].'">'.$charf.t($field[2]).'<dt>';
					echo '<dd><input type = "password" name = "'.encryptRSA($fname).'" value = "'.$value.'"';
					echo ' class = "'.$field[3].'"'.$size.$maxlength.'></dd><br />';
				break;
				// **************
				// TEXTAREA - 1-FieldName  2-TextTitle  3-className, 4 - maxlimit
				// **************
				case 'text_code': case 'text_rcode' :
					$txt = t($field[2]);
					$maxtxt = isset($field[3]) ? 
					' maxlength = "'.$field[3].'" onkeypress = "return textarea_max(this, \''.$field[3].'\');"' : '';
					if (!empty($txt)) {echo $txt.'<br />';}
					if (isset($_SESSION[HURI]['tmp'][$field[1]])) {$editor_html = $_SESSION[HURI]['tmp'][$field[1]];}
					else {$editor_html = isset($data[$field[1]]) ? $data[$field[1]] : '';}
					$read_only = $field[0] == 'text_rcode' ? ' readonly = "readonly"' : '';
					echo '<textarea name = "'.$fname.'" id = "'.$fname.'"'.$maxtxt.$read_only.'>';
					echo $editor_html.'</textarea><br /><br />';
					break;
				// **************
				// TEXTAREA eBookRTE(WYSIWYG) - 1-FieldName  2-TextTitle  3-className
				// **************
				case 'text_area':
					$txt = t($field[2]);
					$wwith = defined('RTE_with') ? RTE_with : 550;
					$wheight = defined('RTE_height') ? RTE_height : 300;
					$editor_css = defined('RTE_CSS') ? RTE_CSS : 'css/content.css';
					$rte_tb1 = defined('RTE_TB1') ? $field[1].'.toolbar1 += \','.RTE_TB1.'\';' : '';
					$rte_tb2 = defined('RTE_TB2') ? $field[1].'.toolbar2 = \','.RTE_TB2.'\';' : '';
					$rte_tb3 = defined('RTE_TB3') ? $field[1].'.toolbar3 = \','.RTE_TB3.'\';' : '';
					$rte_tb4 = defined('RTE_TB4') ? $field[1].'.toolbar4 = \','.RTE_TB4.'\';' : '';
					$smilley = defined('SMILLEY') ? $field[1].'.smilley = \','.SMILLEY.'\';' : '';
					$smilley_txt = defined('SMILLEY_TXT') ? $field[1].'.smilleytxt = \''.SMILLEY_TXT.'\';' : '';
					$add_cmd = defined('ADD_CMD') ? $field[1].'.addcmde = \''.ADD_CMD.'\';' : '';
					$manual_cmd = defined('MANUAL_CMD') ? $field[1].'.addcmdi = \''.MANUAL_CMD.'\';' : '';
					if (!empty($txt)) {echo $txt.'<br />';}
					$editor_html = isset($data[$field[1]]) ? clean($data[$field[1]]) : '';
					$editor_html = str_replace(array(chr(0),chr(10),"\\",chr(34),chr(39)), 
						array("","","&#92;","&quot;","&#39;"), $editor_html);
					echo '<textarea id = "'.$field[1].'" class="getedit" rows="20" cols="50">';
					echo $editor_html.'</textarea>';
					echo '<script type = "text/javascript">
						var '.$field[1].' = startEditor(\''.$field[1].'\');
						'.$field[1].'.wwidth = '.$wwith.';
						'.$field[1].'.wheight = '.$wheight.';
						'.$field[1].'.cssfile = \''.$editor_css.'\';
						'.$rte_tb1.$rte_tb2.$rte_tb3.$rte_tb4.$smilley.$smilley_txt.$add_cmd.$manual_cmd.'
						'.$field[1].'.displayEditor();
					</script>';
					$rte .= 'uSubmit(\''.$field[1].'\');';
				break;
				// **************
				// COMBOIMAGE  - 1-ID,name  2-TextTitle  3-Folder  4- Extensions 5-Size width  6-Size height
				// 7-Text for empty combo
				// **************	
				case 'comboimage':
					$path = getInfo('ROOT_DIR').'/'.$field[3];
					echo '<div id = "div'.$field[1].'" class = "preview">';
					echo '<div id = "i'.$field[1].'" class = "preview_image">';
					$width = !empty($field[5]) ? $field[5] : '158px';
					$height = !empty($field[6]) ? $field[6] : '158px';
					echo '<img id = "img1'.$field[1].'" ';
					if (isset($_SESSION[HURI]['tmp'][$field[2]])) {
						echo 'src = "'.$_SESSION[HURI]['tmp'][$field[2]].'"';
					} else {echo (isset($data[$field[1]]) ? 'src = "'.$data[$field[1]].'"' : '');}
					echo ' width = "'.$width.'" height = "'.$height.'"/>';
					echo '</div>';
					$question = !empty($field[7]) ? $field[7] : 'none';
					echo t($field[2]); $extensions = explode('|', $field[4]);
					echo '<br /><select name = "'.$field[1];
					echo '" onChange = "javascript:chgImg(\'img1'.$field[1].'\',\''.$field[3].'\',this)"> ';
					echo '<option value = "">'.t($question).'</option>';
					if (is_dir($path)) {
						$fd = opendir($path);
						while (($file = readdir($fd)) == true) {
							clearstatcache();
							$ext = strrchr($file, '.');
							if (in_array($ext, $extensions)) {
								if (isset($_SESSION[HURI]['tmp'][$field[2]]) && 
								$_SESSION[HURI]['tmp'][$field[2]] == $field[3].'/'.$file) {
									$selected = ' selected = "selected"';
								} else {
									$selected = isset($data[$field[1]]) && $data[$field[1]] == $field[3].'/'.$file ? 
										' selected = "selected"' : '';
								} echo '<option value = "'.$field[3].'/'.$file.'"'.$selected.'>'.$file.'</option>';
							}
						}
					}
					echo '</select></div><br />';
				break;
				// **************
				// CHECKBOX WITH SHOW/HIDE PLACE - open_Div
				// **************
				case 'checkboxscrip':
					$name = $field[1];
					if (isset($_SESSION[HURI]['tmp'][$field[2]])) {$value = $_SESSION[HURI]['tmp'][$field[2]];}
					else if ($action == 'edit') {
						$value = isset($field[2]) && isset($data[$field[2]]) ? $data[$field[2]] : $field[2];
					} else {$value = $field[3];}
					$checked = $value ? ' checked' : '';
					echo '<input type = "checkbox" id = "'.$name.'" name = "'.$name.'" value = "'.$value.'"'.$checked;
					echo ' onClick = "javascript:hideplace(\''.$name.'\',\''.$field[4].'\',\''.$field[5].'\');"';
					echo '><label for = "'.$name.'"> '.t($field[2]).'</label>';
					if ($field[4] != 'true') {echo '<br />';}
				break;
				// **************
				// CHOOSE DATE
				// **************	
				case 'choose_date': case 'choose_datetime':
					$name = encryptRSA($field[2]);
					if (isset($_SESSION[HURI]['tmp'][$field[2]])) {$value = $_SESSION[HURI]['tmp'][$field[2]];}
					else {$value = $action == 'edit' && isset($data[$field[1]]) ? $data[$field[1]] : $field[5];}
					$checked = $value ? ' checked' : '';
					$year = date('Y', strtotime($value));
					$month = date('m', strtotime($value));
					$day = date('d', strtotime($value));
					$hour = date('H', strtotime($value));
					$min = date('i', strtotime($value));
					$start = isset($field[3]) ? $field[3] : 2010;
					$end = isset($field[4]) ? $field[4] : 2017;
					echo '<label for = "'.$name.'"> '.t($field[2]).'</label><br />';
					# DAY
					echo '<select name="'.$field[2].'_day" id="'.$name.'">';
					for ($j = 1; $j <= 31; $j++){
						$selected = $j == $day ? ' selected="selected"' : '';
						$val = $j < 10 ? '0'.$j : $j;
						echo '<option value="'.$j.'"'.$selected.'>'.$val.'</option>';
					} echo '</select> ';
					# MONTH
					$lmonth = explode(',', t('month_names'));
					echo '<select name="'.$field[2].'_month">';
					for ($j = 1; $j <= 12; $j++){
						$selected = $j == $month ? ' selected="selected"' : '';
						echo '<option value="'.$j.'"'.$selected.'>'.$lmonth[$j-1].'</option>';
					} echo '</select> ';
					# YEAR
					echo '<select name="'.$field[2].'_year">';
					for ($j = $start; $j <= $end; $j++){
						$selected = $j == $year ? ' selected="selected"' : '';
						echo '<option value="'.$j.'"'.$selected.'>'.$j.'</option>';
					} echo '</select>';
					if ($field[0] == 'choose_datetime') {
						# HOUR
						echo ' - <select name="'.$field[2].'_hour">';
						for ($j = 0; $j <= 23; $j++){
							$selected = $j == $hour ? ' selected="selected"' : '';
							$val = $j < 10 ? '0'.$j : $j;
							echo '<option value="'.$j.'"'.$selected.'>'.$val.'</option>';
						} echo '</select>:';
						# MINUTE
						echo '<select name="'.$field[2].'_min">';
						for ($j = 0; $j <= 59; $j++){
							$selected = $j == $min ? ' selected="selected"' : '';
							$val = $j < 10 ? '0'.$j : $j;
							echo '<option value="'.$j.'"'.$selected.'>'.$val.'</option>';
						} echo '</select><br />';
					}
				break;
				// **************
				// Close Fieldset
				// **************	
				case 'close_fieldset': echo '</div></fieldset>'; break;
				// **************
				// OTHER
				// **************	
				case 'horizontal_line': case 'hr': echo '<hr>'; break;
				case 'br': echo '<br />'; break;
				case 'clear': echo '<div class="clear"></div>'; break;
				case 'choice_Div':
					$class = !isset($data[$field[2]]) || intval($data[$field[2]]) != intval($field[3]) ? 
						' style = "display: none" ' : '';
					echo '<div id = "'.$field[1].'"'.$class.'>';
				break;
				case 'open_Div':
					$display = (isset($data[$field[2]]) && $data[$field[2]] == $field[3]) ||
						(isset($_SESSION[HURI]['tmp'][$field[2]]) && $_SESSION[HURI]['tmp'][$field[2]] == $field[3])
						? 'inline' : 'none';
					echo '<div';
					if ($field[1]) {echo ' id = "'.$field[1].'" style = "display:'.$display.'"';}
					echo '>'; break;
				case "close_Div": echo '</div>'; break;
				case "newhidden": 
					if ($action == 'new') {
						echo '<input type = "hidden" name = "'.$field[1].'" ';
						echo 'value = "'.encryptRSA($field[2], false).'">';
					} break;
				case "updatefield": 
					if ($action == 'edit') {
						echo '<input type = "hidden" name = "'.$field[1].'" ';
						echo 'value = "'.encryptRSA($field[2], false).'">';} break;
				case "redirect": 
					echo '<input type = "hidden" name = "'.encryptRSA($field[1], false).'" ';
					echo 'value = "'.encryptRSA($field[3], false).'">'; break;
				case "none": break;
			}
		}
		// HIDDEN FIELDS
		if (isset($id)) {
			echo '<input type = "hidden" name = "id" value = "'.encryptRSA($id, false).'">';
			echo '<input type = "hidden" name = "'.encryptRSA('tks').'" ';
				echo 'value = "'.encryptRSA($data['key_security'], false).'">';
		}
		if ($get){
			$vget = isset($uri[1]) ? implode(',', $get) : '';
			echo '<input type="hidden" name="'.encryptRSA('get').'" value="'.$vget.'">';
			$vuri = isset($uri[1]) ? implode(',', $uri) : '';
			echo '<input type="hidden" name="'.encryptRSA('uri').'" value="'.$vuri.'">';
			
			if (isset($get['admin'])) {echo '<input type = "hidden" name = "adm" value = "'.$get['admin'].'">';}
			if (isset($get['tid'])) {
				echo '<input type = "hidden" name = "'.encryptRSA('tid').'"';
				echo ' value = "'.encryptRSA($get['tid'], false).'">';
			}
			if (isset($get['pd'])) {echo '<input type = "hidden" name = "pd" value = "'.$get['pd'].'">';}
			if (isset($get['pn'])) {echo '<input type = "hidden" name = "pn" value = "'.$get['pn'].'">';}
			if (isset($get['tb'])) {echo '<input type = "hidden" name = "tb" value = "'.$get['tb'].'">';}
			if (isset($get['fg'])) {echo '<input type = "hidden" name = "fg" value = "'.$get['fg'].'">';}
			if (isset($get['gm'])) {echo '<input type = "hidden" name = "gm" value = "'.$get['gm'].'">';}
			
			
		
		
			if (isset($get['fp'])) {
				echo '<input type = "hidden" name = "fp" value = "'.encryptRSA($get['fp'], false).'">';
			}
			if (isset($get['parent'])) {echo '<input type = "hidden" name = "parent" value = "'.$get['parent'].'">';}
			if (isset($data['section_id'])) {
				echo '<input type = "hidden" name = "ci" value = "'.$data['section_id'].'">';
			}
		}
		if (isset($data) && isset($data['wtype'])) {
			echo '<input type = "hidden" name = "wtype" value = "'.$data['wtype'].'">';
		}
		if (isset($form['last_command'])) {
			echo '<input type = "hidden" name = "last_command" value = "'.$form['last_command'].'">';
		}
		echo '<input type = "hidden" name = "lang_id" value = "'.encryptRSA($lang_id, false).'">';
		echo '<input type = "hidden" name = "'.encryptRSA('last_action').'" value = "'.encryptRSA($action, false).'">';
		if (!empty($rte)) {$rte = ' onclick = "'.$rte.'"';} else {$rte = '';}
		echo '<input type = "submit" class = "bigbutton" name = "'.encryptRSA('submit').'" ';
			echo 'value = "'.t('submit').'"'.$rte.'>';
		if ($form['cancel']) {
			echo '<input type = "submit" class = "bigbutton" name = "'.encryptRSA('cancel').'" ';
			echo 'value = "'.t('cancel').'">';
		} echo '</form></div>';
		if (HTML5) {echo '</section>';}
		echo chr(13); unset($_SESSION[HURI]['tmp']);
	} else
	
# **************************************************************************************************************
# --------------------------------------------------------------------------------------------------------------
#
# 									L  I  S  T 
#
# --------------------------------------------------------------------------------------------------------------
# **************************************************************************************************************

	if ($action == 'list') {
		table_filterBy($form, 'top_filter_by');
		$mygroup = $_SESSION && isset($_SESSION[HURI][encryptRSA('group_member')]) ? 
			decryptRSA($_SESSION[HURI][encryptRSA('group_member')]) : '0';
		$table_header = !empty($form['table_header']) ? explode(',', $form['table_header']) : array();
		$table_hsize  = !empty($form['table_hsize'])  ? explode(',', $form['table_hsize']) : array();
		$table_fields = !empty($form['table_fields']) ? explode(',', $form['table_fields']) : array();
		$table_cspans = !empty($form['table_fields']) ? explode(',', $form['table_cspans']) : array();
		$query_fields = isset($form['query_fields']) ? $form['query_fields'] : '*';
		$table_where = isset($form['query_where']) ? $form['query_where'] : '';
		$qorder = isset($form['list_order']) && !empty($form['list_order']) ? $form['list_order'] : '';
		if (isset($form['list_order']) && !empty($form['list_order'])){
			$qorder = $form['order'] == 1 ? "ORDER BY order_content ASC" : $form['order'];
		} else {$qorder = "";}
		$qorder = isset($form['order']) && $form['order'] == 1 ? " ORDER BY order_content ASC" : "";
		if (empty($qorder) && isset($form['order_by'])) {$qorder = $form['order_by'];}
		$qtotal= "SELECT count(id) AS total FROM ".PREFIX.$form['query_table'].$table_where;
		if ($rcount = db() -> query($qtotal)) {$r = dbfetch($rcount); $total = $r['total']; unset($rcount);} 
			else {$total = 0;}
		$query = "SELECT $query_fields FROM ".PREFIX.$form['query_table'].$table_where." ".$qorder;
		$limit_link = '<a href="'.$root.'?'.$uadmin.'='.$gadmin.'&amp;action=list'.$ukey;
		$limit = isset($form['limits']) && is_numeric($form['limits']) ? $form['limits'] : 10;
		$total_fields = !empty($limit) ? ceil($total/$limit) : ceil($total);
		$section_id = isset($form['section_id']) ? $form['section_id'] : '';
		$no_access = '<td class="center"><img src="'.load_icon('img_noaccessd').'" alt="'.t('no_access').'" /></td>';
		$pageNum = !empty($get['pn']) ? $get['pn'] : ''; $search_query = '';
		if (empty($pageNum)) {$pageNum=1;} else
		if (!empty($pageNum) && $total_fields+1 == $pageNum) {$pageNum = $total_fields;}
		$pn = $pageNum>1 ? '&amp;pn='.$pageNum : '';
		$current = isset($pageNum) && is_numeric($pageNum) ? $pageNum : (empty($pageNum) ? 1 : 0);
		if ($current == 0 || ($current > $total_fields && $total_fields!=0)) {
			echo t('error_404'); unset($data); return;}
		$query .= !empty($limit) ? ' LIMIT '.($current - 1) * $limit.','.$limit : ''; 
		$k = !empty($limit) ? ($current-1)*$limit + 1 : 1;
		$result = db() -> query($query);
		#   *****   T A B L E   **********
		echo '<table border="1" width="100%" cellspacing="0" class="table_ebook">';
		// Header
		echo '<tr>';
		for ($i=0; $i<count($table_header); $i++) {
		 	$col_spans = $table_cspans[$i] == '1' ? '' : ' colspan="'.$table_cspans[$i].'"';
			echo '<th';
			echo isset($table_hsize[$i]) ? ' width="'.$table_hsize[$i].'" ': '';
			echo ' scope="col"'.$col_spans;
			echo '>'.$table_header[$i].'</th>';
		} echo '</tr>'; $k = 1; $kk = ($current - 1) * $limit;
		// EMPTY ROWS
		if (isset($total) && $total == 0) {
			echo '<tr>';
			for ($i=0; $i<count($table_fields); $i++) {echo '<td class="center">&hellip;&nbsp;</td>';} 
			echo '</tr>';
		}
		// VALUES ROWS
		while ($r = dbfetch($result)) {
			if ($k%2) {echo '<tr>';} else {echo '<tr class="even">';}
			// MAKE SURE ORDER_CONTENT IS ALLRIGHT
			if (isset($form['order']) && $r['order_content'] != ($kk+$k)) {
			 	$order_content = $kk+$k;
				$sql = "UPDATE ".PREFIX.$form['query_table']." SET order_content = ? WHERE id = ?;";
				$res = db() -> prepare($sql);
				$res -> execute(array($order_content, $r['id']));
			}
			for ($i=0; $i<count($table_fields); $i++) {
				$dks = isset($form['delkey']) && isset($r[$form['delkey']]) ? 
					'&amp;dks='.encryptRSA($r[$form['delkey']], false) : '';
				$tid = $r['id'];
				$id = isset($r['key_security']) ? '&amp;tid='.$tid : ''; 
				$tks = '&amp;tks='.encryptRSA($r['key_security'], false);
				$edit = '<a href="'.$root.'?'.$uadmin.'='.$gadmin.'&amp;action=edit';
				$edit .= $id.$tb.$pn.$gmm.$fgg.$fpp.$tks.$ukey.'" title="'.t('edit').'">';
				if (isset($r['sec_type']) && $r['sec_type'] == 2) {
					$plugin_name = retrieve_mysql('plugins', "id", $r['plug_id'], 'sef_file',"");
					$content = '<a href="'.$root.'?admin='.$plugin_name['sef_file'].'&amp;action=list';
				} else {$content = '<a href="'.$root.'?'.$uadmin.'='.$gadmin.'&amp;action=content';}
				$content.= $id.$tks.$tb.$ukey.$pn.'" title="'.t('content').'">';
				$delete = '<a href="'.$root.'?'.$uadmin.'='.$gadmin.'&amp;action=delete';
				$delete.= $id.$dks.$tb.$ukey.$pn.'" title="'.t('delete').'"';
				switch ($table_fields[$i]) {
					case 'id': echo '<td class="center">'.$r['id'].'</td>'; break;
					case '%order': echo '<td class="center">';
						$allowed = isset($form['edit_rights']) && $form['edit_rights'] == 1 ? true : false;
						if (!$allowed) {echo '<img src="'.load_icon('img_minus').'" alt="'.t('none').'" />'; break;}
						$up = $r['order_content'] == 1 || $kk == 1 ? 
							'<img src="'.load_icon('img_minus').'" alt="'.t('none').'" />' :
							'<a href="'.$root.'?'.$uadmin.'='.$gadmin.'&amp;action=moveup&amp;oc='.$r['order_content'].
							$ukey.$pn.'" title="'.t('move_up').'"><img src="'.load_icon('img_up').
								'" alt="'.t('move_up').'" /></a>';
						$link_down = $root.'?'.$uadmin.'='.$gadmin.'&amp;action=movedown&amp;oc='.$r['order_content'];
						$link_down.= $ukey.$pn;
						$down = $kk+$k == $total ? 
							'<img src="'.load_icon('img_minus').'" alt="'.t('none').'" />' : 
							'<a href="'.$link_down.'" title="'.t('move_down').'"><img src="'.load_icon('img_down').
								'" alt="'.t('move_down').'" /></a>';
						echo $up.' '.$down;
						echo '</td>'; break;
					case '%edit':
						$allowed = isset($form['edit_rights']) && $form['edit_rights'] == 1 ? true : false;
						$edit_list = isset($form['edit_id']) ? explode(',',$form['edit_id']) : '';
						$list = !empty($edit_list) && in_array($r['id'], $edit_list) ? false : true;
						$group_list = isset($form['edit_group']) ? explode(',',$form['edit_group']) : '';
						$group = !empty($group_list) && isset($form['key_group']) && isset($r[$form['key_group']]) 
							&& in_array($r[$form['key_group']], $group_list) ? false : true;
						if ($allowed && $list && $group) {
							echo '<td class="center">'.$edit.'<img src="'.load_icon('img_edit').'" ';
							echo 'alt="'.t('edit').'" /></a></td>';
						} else {echo $no_access;}
					break;
					case '%delete':
						$allowed = isset($form['delete_rights']) && $form['delete_rights'] == 1 ? true : false;
						$delete_list = isset($form['delete_id']) ? explode(',',$form['delete_id']) : '';
						$list = !empty($delete_list) && in_array($r['id'], $delete_list) ? false : true;
						$group_list = isset($form['delete_group']) ? explode(',',$form['delete_group']) : '';
						$group = !empty($group_list) && isset($form['key_group']) && 
							in_array($r[$form['key_group']], $group_list) ? false : true;
						$delete_id = isset($form['delete_id']) ? $form['delete_id'] : '';
						if ($allowed && $list && $group) {
							$deltxt = $taction.'_delete';
							$delete .= !empty($deltxt) ? 'onClick="return confirm(\''.t($deltxt).'\');">' : '>';
							if ($delete_id != $r['id']) {}
							echo '<td class="center">'.$delete;
							echo '<img src="'.load_icon('img_delete').'" alt="'.t('delete').'" /></a></td>';
						} else {echo $no_access;}
					break;
					case '%content':
						$link = $r[$section_id] == 0 ? $no_access :
							'<td class="center">'.$content.'<img src="'.load_icon('img_admin').'" alt="'.
								t('content').'" /></a></td>';
						echo $link;
					break;
					case '%install':
						$image = '<img src="'.load_icon('img_install').'" alt="'.t('install').'" />';
						$action = '&amp;action=install';
						$link = $action.'&amp;tid='.$r['id'].'&amp;tks='.encryptRSA($r[$form['edit_ks']],false);
						$install = '<td class="center"><a href="'.$root.'?'.$uadmin.'='.$gadmin.$link.$ukey;
						$install .= '">'.$image.'</a></td>';
						$option = $r['installed'] ? $no_access : $install;
						echo $option;
					break;
					case '%dtable':
						$image = '<img src="'.load_icon('img_delete').'" alt="'.t('drop_plugin').'" />';
						$action = '&amp;action=dtable';
						$dropdtxt = t('iplugins_del');
						$link = $action.'&amp;tid='.$r['id'].'&amp;dks='.encryptRSA($r[$form['edit_ks']],false);
						$drop = '<td class="center"><a href="'.$root.'?'.$uadmin.'='.$gadmin.$link.$ukey;
						$drop .= '" title="'.t('drop_plugin').'"';
						$drop .= ' onClick="return confirm(\''.$dropdtxt.'\');">'.$image.'</a></td>';
						$option = $r['installed'] ? $drop : $no_access;
						echo $option;
					break;
					case '%ctable':
						$image = '<img src="'.load_icon('img_clean').'" alt="'.t('empty_table').'" />';
						$action = '&amp;action=ctable';
						$dropdtxt = t('iplugins_clear');
						$link = $action.'&amp;tid='.$r['id'].'&amp;dks='.encryptRSA($r[$form['edit_ks']],false);
						$clear = '<td class="center"><a href="'.$root.'?'.$uadmin.'='.$gadmin.$link.$ukey;
						$clear .= '" title="'.t('empty_table').'"';
						$clear .= ' onClick="return confirm(\''.$dropdtxt.'\');">'.$image.'</a></td>';
						$option = $r['installed'] ? $clear : $no_access;
						echo $option;
					break;
					case '%padmin':
						$image = '<img src="'.load_icon('img_admin').'" alt="'.t('admin').'" />';
						$action = '&amp;action=list';
						$clear = '<td class="center"><a href="'.$root.'?admin='.$r[$form['padmin']].$action.$ukey;
						$clear .= '">'.$image.'</a></td>';
						$option = $r['installed'] ? $clear : $no_access;
						echo $option;
					break;
					case '[x1]': 
						if (isset($form['[x1]'])){
							$extlist = explode(',', $form['[x1]']);
							$name = retrieve_mysql($extlist[1], $extlist[2], $r[$extlist[0]], $extlist[3]);
							echo '<td class="center">'.$name[$extlist[3]].'</td>';
						} else {echo '<td class="center">NA</td>';}
					break;
					default: $cfield = $table_fields[$i]; $cf = true;
						if (substr($cfield,0,1) == '@') {
							$cfield = substr($cfield,1);
							echo '<td class="center">'.decryptRSA($r[$cfield]).'</td>';
						} else
						if (substr($cfield,0,1) == '#') {
							$xfield = str_replace('#', '', $cfield);
							$xfield = explode('|',$xfield);
							$lfield = explode(',',t($xfield[0])); $cfield = $xfield[1];
							echo '<td class="center">'.$lfield[$r[$cfield]].'</td>';
						} else {echo '<td class="center">'.$r[$cfield].'</td>';}
					 break;
				}
			} echo '</tr>'; $k++; $kk+1;
		} echo '</table>';
		if ($total_fields > 1 && !empty($limit)) {paginator($current, $total_fields, $search_query, $limit_link);}
		# FILTER BY
		table_filterBy($form, 'filter_by');
		if (isset($form['back_list'])) {
			$links = explode(',', $form['back_list']);
			$url_admin = isset($form['admin']) ? $form['admin'] : $uadmin;
			$url1 = isset($links[0]) ? $links[0] : 'root';
			if ($url1 == 'root') {$url2 = '';} 
			else {$url2 = isset($links[1]) ? $links[1] : 'list'; $url2 = '&amp;action='.$url2;}
			echo '<a href="'.$root.'?'.$url_admin.'='.$url1.$url2.$ukey.'">'.t('back').'</a>';
		} else
		if (isset($form['back_root']) && $form['back_root'] != false) {
			echo '<a href="'.$root.'?admin=root'.$ukey.'">'.t('back_root').'</a>';
		} else
		if (isset($form['back_bigroot']) && $form['back_bigroot'] != false) {
			echo '<a href="'.$root.'?admin=bigroot'.$ukey.'">'.t('back_bigroot').'</a>';
		} return;
	} else
# **************************************************************************************************************
# --------------------------------------------------------------------------------------------------------------
#
# 									D  E  L  E  T  E
#
# --------------------------------------------------------------------------------------------------------------
# **************************************************************************************************************

	if ($action == 'delete') {
		$id = isset($get['tid']) ? $get['tid'] : null;
		$dks = decryptRSA($get['dks']);
		$fdks = isset($form['delkey']) ? $form['delkey'] : 'del_key';
		$parent = isset($get['parent']) ? $get['parent'] : null;
		$order_where = isset($form['order_where']) ? $form['order_where'] : '';
		$data = retrieve_mysql($form['query_table'], 'id', $id, '*', " AND $fdks = '$dks'");
		if (!$data) {echo '<h3>'.t('wrong_key').'</h3>'; return;}
		$language = isset($get['lang']) ? ' AND lang_id = '.$lang_id : ' AND lang_id = 1';
		$order_where = str_replace('%lang_id', $language, $order_where); $n = 0;
		if (isset($form['order_fields'])) {
			$order_fields = explode(',', $form['order_fields']);
			for ($i = 0; $i < count($order_fields); $i++){
				$list = explode('@', $order_fields[$i]);
				if ($data[$list[0]]) {$order_where = str_replace($list[1], $data[$list[0]], $order_where);}
			}
		}
		# DELETE FIELD
		$qwr = "DELETE FROM ".PREFIX.$form['query_table']." WHERE id = ? AND $fdks = ?";
		if ($res = db() -> prepare($qwr)) {$res = dbbind($res, array($id, $dks), 'is');}
		unset($res, $qwr);
		# DELETE HERITED DATA
		if (isset($form['section_id']) && isset($data[$form['section_id']]) && isset($form['del_herited'])){
			if (isset($form['del_herited'][$data[$form['section_id']]])){
				$list = explode(',', $form['del_herited'][$data[$form['section_id']]]);
				$dqwr = "DELETE FROM ".PREFIX.$list[0]." WHERE ".$list[1];
				$dqwr = str_replace('%lang_id', $language, $dqwr);
				$dqwr = str_replace('%id', $id, $dqwr);
				if ($rx = db() -> query($dqwr)){$r = dbfetch($rx);}
			}
		} unset($rx, $dqwr);
		# AUTO RE-ORDER
		if (isset($form['order']) && $form['order'] == 'true') {
			$query = "SELECT id,order_content 
				FROM ".PREFIX.$form['query_table'].$order_where." ORDER BY order_content ASC";
			if ($result = db() -> query($query)){
				while ($r = dbfetch($result)) {
					$id = $r['id']; $n++;
					$sql =  "UPDATE ".PREFIX.$form['query_table']." SET order_content = ? WHERE id = ?";
					if ($q = db() -> prepare($sql)) {$q = dbbind($q, array($n, $id), 'ii'); unset($q);}
				}
			}
		}
		echo '<div class="msgsuccess">'.t('update_sucess').'</div>'; unset($data);
		if ($parent) {echo '<meta http-equiv="refresh" content="1; url='.$root.'?page='.$parent.$pn.'">';}
		else {echo '<meta http-equiv="refresh" content="1; url='.$link.'">';} unset($form); return;
	} else

# **************************************************************************************************************
# --------------------------------------------------------------------------------------------------------------
#
# 									C  O  N  T  E  N  T
#
# --------------------------------------------------------------------------------------------------------------
# **************************************************************************************************************
	if ($action == 'content') {
		$mygroup = load_value('user_gm');
		$tid = $get['tid']; $id = $tid;
		$tks = decryptRSA($get['tks']);
		$table_fields = $form['content_fields'];
		$no_access = '<td class="center"><img src="'.load_icon('img_noaccessd').'" alt="'.t('no_access').'" /></td>';
		$data = retrieve_mysql($form['query_table'], "id", $id, $table_fields, " AND key_security = '$tks'");
		$sub_content = isset($data['title']) ? '"'.$data['title'].'"' : t('content');
		$edit_id = isset($form['edit_content'][$data['sec_type']]) ? 
			explode(',', $form['edit_content'][$data['sec_type']]) : array('0');
		$delete_id = isset($form['del_content'][$data['sec_type']]) ? 
			explode(',', $form['del_content'][$data['sec_type']]) : array('0');
		if (isset($data)){
			echo '<h1 class="h1_title">'.$data['title'].'</h1>';
			$allowed = isGroupAllowed($data) ? true : false;
			$add_content = isGroupAllowed($data, 'add_content');
			$only_author = isset($data['only_author']) && $data['only_author'] == 1 && $mygroup != 1 ? true : false;
			# PLUGIN
			if ($data['sec_type'] == 2) {
				$action = $action == 'content' ? 'list' : $action;
				$plugin = retrieve_mysql('plugins', 'id', '"'.$data['plug_id'].'"', 'id,admin_func', 
					" AND installed = 1");
				if ($plugin) {
					$fname = $plugin['admin_func'];
					if (function_exists($fname)) {call_user_func_array($fname, array($action));}
					else {echo '</div>'; set_error();}
				} return;
			}
			# NON PLUGIN
			else if ($data['sec_type'] != 2) {
				$control = isset($form['control_content']) && isset($data[$form['control_content']]) ? 
					$data[$form['control_content']] : 1;
				$field = isset($form['content'][$control]) ? $form['content'][$control] : '';
				if ($lang_id != 1 || isset($get['lang'])) {$lang = '&amp;lang='.$lang_id;} else {$lang = '';}
				if (empty($field)) {echo '</div>'; return;}
				for ($i=0; $i<count($field); $i++) {
					$content = !empty($field[$i]) ? explode(',', $field[$i]) : '';
					switch ($content[0]) {
						case 'new_content':
							if (isset($content[6])) {
								$wwhere = isset($content[7]) ? ' AND wtype = '.$content[7] : '';
								$language = isset($get['lang']) ? ' AND lang_id = '.$lang_id : ' AND lang_id = 1';
								$max = retrieve_mysql($content[6], 'section_id', $id, 'count(id) AS total', 
									$wwhere.$language);
							}
							$txt = t($content[1]);
							$sid = isset($data[$content[5]]) ? $data[$content[5]] : $id;
							$here = '<a href="'.$root.'?admin='.$content[2];
							$here .= '&amp;action=new&amp;'.$content[4].'='.encryptRSA($sid, false);
							$here .= $lang.$ukey.'" title="'.t('add_content').'">'.t('here').'</a>';
							$txt = str_replace(array('$here', '$sub'), array($here, $sub_content), $txt);
							if (isset($max['total']) && $data['lcontent'] != 0 && $max['total']>=$data['lcontent']) {
								$txt = '';} else
							if (isset($form['edit_crights'][$data['sec_type']]) && 
								$form['edit_crights'][$data['sec_type']] == 0) {$txt = '';}
							else if ($add_content){echo '<p>'.$txt.'</p>';}
							else {echo '<br />';}
						break;
						case 'info': 
							if (isset($content[1])) {echo '<div class="msginfo"><h3>'.t($content[1]).'</h3></div>';}
						break;
						case 'br': echo '<br />'; break;
						case 'drawtable':
							$ltable = explode('@',$content[1]);
							$query_fields = isset($content[4]) ? $content[4] : '*';
							$query_fields = str_replace('@',',',$query_fields);
							$table_where = isset($content[5]) ? $content[5] : '';
							$table_where = str_replace('%id', $data['id'], $table_where);
							$table_where = isset($form['control_subcontent']) && 
								isset($data[$form['control_subcontent']])
								? str_replace('%sid', $data[$form['control_subcontent']], $table_where) : $table_where;
							$table_where = ' WHERE '.$table_where;
							$limit = isset($content[10]) ? $content[10] : '10';
							$limit_link = '<a href="'.$root.'?admin='.$gadmin.'&amp;action='.$get['action'];
							$limit_link .= isset($get['tid']) ? '&amp;tid='.$get['tid'] : '';
							$limit_link .= isset($get['tks']) ? '&amp;tks='.$get['tks'] : '';
							$limit_link .= $ukey;
							$order = isset($content[11]) ? ' '.$content[11] : ' ORDER BY order_content ASC';
							$qtotal = "SELECT count(id) AS total FROM ".PREFIX.$ltable[0].' '.$table_where;
							$language = isset($get['lang']) ? ' AND lang_id = '.$lang_id : ' AND lang_id = 1';
							$qtotal = str_replace('%lang_id', $language, $qtotal);
							if ($rcount = db() -> query($qtotal)) {
								$rtt = dbfetch($rcount); $total = $rtt['total']; unset($rcount);
							}
							$total_fields = !empty($limit) ? ceil($total/$limit) : ceil($total);
							$query = "SELECT $query_fields FROM ".PREFIX.$ltable[0].' '.$table_where.$order;
							$pageNum = !empty($get['pn']) ? $get['pn'] : '';
							if (empty($pageNum)) {$pageNum=1;} else
							if (!empty($pageNum) && $total_fields+1 == $pageNum) {$pageNum = $total_fields;}
							$pn = $pageNum>1 ? '&amp;pn='.$pageNum : '';
							$current = isset($pageNum) && is_numeric($pageNum) ? $pageNum : (empty($pageNum) ? 1 : 0);
							if ($current == 0 || ($current > $total_fields && $total_fields!=0)) {
								echo t('error_404'); unset($data); return;
							}
							$query .= !empty($limit) ? ' LIMIT '.($current - 1) * $limit.','.$limit : '';
							$query = str_replace('%lang_id', $language, $query);
							$k = !empty($limit) ? ($current-1) * $limit + 1 : 1;
							$result = db() -> query($query);
							$table_header = explode('@',$content[6]);
							$table_fields = explode('@',$content[7]);
							$table_cspans = explode('@',$content[8]);
							$table_hsize = explode('@',$content[9]);
							$link1 = isset($ltable[1]) ? 
								$root.'?admin='.$ltable[1].'&amp;action=' : $root.'?admin='.$ltable[0].'&amp;action=';
							#   *****   T A B L E   **********
							echo '<table border="1" width="100%" cellspacing="0" class="table_ebook">';
							// Header
							echo '<tr>';
							for ($j=0; $j<count($table_header); $j++) {
							 	$col_spans = $table_cspans[$j] == '1' ? '' : ' colspan="'.$table_cspans[$j].'"';
								echo '<th';
								echo isset($table_hsize[$j]) ? ' width="'.$table_hsize[$j].'" ': '';
								echo ' scope="col"'.$col_spans;
								echo '>'.t($table_header[$j]).'</th>';
							} echo '</tr>'; $k = 1; $kk = ($current - 1) * $limit;
							// EMPTY ROWS
							if ($total == 0) {
								echo '<tr>';
								for ($j=0; $j<count($table_fields); $j++) {
									echo '<td class="center">&hellip;&nbsp;</td>';
								} echo '</tr>';
							}
							// VALUES ROWS
							while ($r = dbfetch($result)) {
								if (isset($r['admin_by']) && !isGroupAllowed($r) && $mygroup != 1) {continue;}
								if ($k%2) echo '<tr>'; else echo '<tr class="even">';
								for ($j=0; $j<count($table_fields); $j++) {
									$id = isset($r['key_security']) ? '&amp;tid='.$r['id'] : '';
									$tks = '&amp;tks='.encryptRSA($r['key_security'], false);
									$dks = isset($r['del_key']) ? '&amp;dks='.encryptRSA($r['del_key'], false) : '';
									switch ($table_fields[$j]) {
										# ORDER
										case '%order': 
											echo '<td class="center">';
											$minus = '<img src="'.load_icon('img_minus').'" alt="'.t('none').'" />';
											if (!$allowed || $only_author) {echo $minus; break;}
											$ct = '&amp;id='.$r['id'].'&amp;oc='.$r['order_content'].'&amp;tid='.$tid;
											$ct .= '&amp;ha='.$get['admin'].$ukey.$pn;
											$link_up = $link1.'cmoveup'.$ct;
											$up = $r['order_content'] == 1 || $kk == 1 || $total == 1 ? $minus :
												'<a href="'.$link_up.$lang.'" title="'.t('move_up').'">'.
												'<img src="'.load_icon('img_up').'" alt="'.t('move_up').'" /></a>';
											$link_down = $link1.'cmovedown'.$ct;
											$down = $kk+$k == $total ? $minus :
												'<a href="'.$link_down.$lang.'" title="'.t('move_down').'">'.
												'<img src="'.load_icon('img_down').'" alt="'.t('move_down').'" /></a>';
											echo $up.' '.$down;
											echo '</td>';
										break;
										# EDIT
										case '%edit':
											if ($allowed) {
												$edit = '<a href="'.$link1.'edit'.$id.$tks.$ukey.$pn.
													'" title="'.t('edit').'">';
												if (isset($r['admin_by']) && !isGroupAllowed($r)) {
													echo $no_access; break;
												}
												if ($only_author == true && isset($r['author_id']) && 
													$r['author_id'] != $uid && !in_array($r['id'], $edit_id)) {
														echo $no_access; break;
												}
												if (!in_array($r['id'], $edit_id)) {
													echo '<td class="center">'.$edit;
													echo '<img src="'.load_icon('img_edit').'" ';
													echo 'alt="'.t('edit').'" /></a></td>';
												} else {echo $no_access; break;}
											} else {echo $no_access;}
										break;
										# DELETE
										case '%delete':
											if ($allowed) {
												$deltxt = $ltable[0].'_delete';
												$delete = '<a href="'.$link1.'delete'.$id.$dks.$ukey.$pn.'" ';
												$delete .= 'title="'.t('delete').'"';
												$delete .= !empty($deltxt) ? 
													' onClick="return confirm(\''.t($deltxt).'\');">' : '>';
												if (isset($form['del_section_id'][$data['sec_type']]) && 
													$form['del_section_id'][$data['sec_type']] == $r['id']) {
													echo $no_access; break;
												}
												if (isset($r['admin_by']) && !isGroupAllowed($r)) {
													echo $no_access; break;
												}
												if ($only_author == true && isset($r['author_id']) && 
													$r['author_id'] != $uid && !in_array($r['id'], $delete_id)) {
													echo $no_access; break;
												}
												if (!in_array($r['id'], $delete_id)) {
													echo '<td class="center">'.$delete;
													echo '<img src="'.load_icon('img_delete').'" ';
													echo 'alt="'.t('delete').'" /></a></td>';
												} else {echo $no_access; break;}
											} else {echo $no_access;}
										break;
										# SUB-CONTENT
										case '%content':
											$enabled = isset($r[$content[2]]) && $r[$content[2]] == 0 ? false : true;
											echo '<td class="center">';
											if ($enabled) {
												$xcontent = '<a href="'.$root.'?admin='.$content[12].
													'&amp;action=content'.$id.$tks.$ukey.$pn.'"';
												$xcontent .= ' title="'.t('content').'">';
												echo $xcontent.'<img src="'.load_icon('img_pages').'" ';
												echo 'alt="'.t('content').'" /></a></td>';
											} else {
												echo '<img src="'.load_icon('img_exclamation').'" ';
												echo 'alt="'.t('content').'" /></td>';
											}
										break;
										# FIELDS
										default: 
											$cfield = $table_fields[$j]; $cf = true;
											if (substr($cfield,0,1) == '#') {
												$xfield = str_replace('#', '', $cfield);
												$xfield = explode('|',$xfield);
												$lfield = explode(',',t($xfield[0])); $cfield = $xfield[1];
												$cf = false;
											}
											if ($cf) {echo '<td>'.$r[$cfield].'</td>';}
											else {echo '<td>'.$lfield[$r[$cfield]].'</td>';}
										break;
									}
								} echo '</tr>'; $k++; $kk+1;
							} break;
						case 'end_table': echo '</table>'; 
							if ($total_fields > 1 && !empty($limit)) {
								paginator($current, $total_fields, $search_query, $limit_link);
							}
						break;
						case 'filter':
							$admin = isset($get['admin']) ? 'admin' : $uri[0];
							$admin = '?'.$admin.'='.$get[$admin];
							$action = isset($get['action']) ? '&amp;action='.$get['action'] : '';
							$tid = isset($get['tid']) ? '&amp;tid='.$get['tid'] : '';
							$tks = isset($get['tks']) ? '&amp;tks='.$get['tks'] : '';
							echo '<p><strong>'.t($content[1]).'</strong>';
							$fields = str_replace('@', ',', $content[3]);
							$where = str_replace('@', ',', $content[4]);
							$query = "SELECT $fields FROM ".$content[2]." WHERE ".$where;
							if ($result = db() -> query($query)){
								while($r = dbfetch($result)){
									echo ' - <a href="'.$root.$admin.$action.$tid.$tks.$ukey;
									echo '&amp;'.$content[5].'='.$r['id'].'" title="'.t('filter_by').'">';
									echo $r[$content[6]].'</a>';
								} unset($result);
							} echo '</p><br />'; break;
						case 'backlink':
							$ladmin = isset($content[2]) ? explode('@',$content[2]) : '';
							$fcontrol = isset($content[5]) && !empty($content[5]) ? explode('@',$content[5]) : '';
							if (!empty($fcontrol)){
								$admin = isset($fcontrol[1]) && isset($data[$fcontrol[1]]) && 
									$data[$fcontrol[1]] != 0 ? $ladmin[1] : $ladmin[0];
								$action = isset($content[3]) && !empty($content[3]) ? '&amp;action='.$content[3] : '';
								$sid = isset($data[$fcontrol[1]]) && $data[$fcontrol[1]] != 0 ? 
									$data[$fcontrol[1]] : $data[$fcontrol[0]];
								$tid = !empty($content[4]) ? '&amp;tid='.$sid : '';
								$herited = retrieve_mysql($admin, "id", $sid, "id,key_security", "");
								$tks = '&amp;tks='.encryptRSA($herited['key_security'],false);
							} else {
								$admin = isset($ladmin[0]) ? $ladmin[0] : $content[2];
								$action = $content[1] == 'false' && isset($content[3]) ? 
									'&amp;action='.$content[3] : '';
								$tks = '';
								$tid = '';
							}
							echo '<a href="'.$root.'?admin='.$admin.$action.$tid.$tks.$lang.$ukey.'" ';
							echo 'title="'.t('back').'">'.t('back').'</a>';
						break;							
					}
				}
			}
		} return;
	} else

# **************************************************************************************************************
# --------------------------------------------------------------------------------------------------------------
#
# 									CHANGE ORDER MOVE UP/DOWN
#
# --------------------------------------------------------------------------------------------------------------
# **************************************************************************************************************
	
	if ($action == 'moveup' || $action == 'movedown' || $action == 'cmoveup' || $action == 'cmovedown') {
		if (!isset($form['order'])) {return;}
		$id = isset($get['id']) && is_numeric($get['id']) ? $get['id'] : '';
		$tid = isset($get['tid']) && is_numeric($get['tid']) ? $get['tid'] : '';
		$num = isset($get['oc']) && is_numeric($get['oc']) ? $get['oc'] : null;
		if ($lang_id != 1 || isset($get['lang'])) {$lang = '&amp;lang='.$lang_id;} else {$lang = '';}
		$language = isset($get['lang']) ? ' AND lang_id = '.$lang_id : ' AND lang_id = 1';
		$order_where = isset($form['order_where']) ? $form['order_where'] : '';
		$order_where = str_replace('%tid', $tid, $order_where);
		$ord_list = isset($form['order_fields']) ? explode(',', $form['order_fields']) : '';
		if (!empty($ord_list)) {
			$ks = isset($get['key_security']) ? $get['key_security'] : '';
			$query = "SELECT * FROM ".$form['query_table']." WHERE id = '$id'";
			if ($result = db()-> query($query)){$data = dbfetch($result); unset($result);}
			for ($k=0; $k < count($ord_list); $k++) {
				$ord = explode('@', $ord_list[$k]);
				$order_where = str_replace($ord[1], $data[$ord[0]], $order_where);
			} unset($data);
		}
		if (!empty($order_where)) {$order = " ".$order_where." AND ";} else {$order = " WHERE ";}
		if ($action == 'movedown' || $action == 'cmovedown') { $n1 = $num+1;
			echo '<h3>'.t('move_down').'</h3>';
			$query = "SELECT * FROM ".PREFIX.$form['query_table'];
			$query .= $order."(order_content = $num OR order_content = $n1) ORDER BY order_content DESC LIMIT 2;";
			$query = str_replace('%lang_id', $language, $query);
			if ($result = db() -> query($query)){
				while ($r = dbfetch($result)) { $id = $r['id'];
				 	$qm = "UPDATE ".PREFIX.$form['query_table']." SET order_content = ? WHERE id = ?";
					if ($qx = db() -> prepare($qm)) {
						$qx = dbbind($qx, array($num, $id), 'ii');
						$num++; unset($qx);
					}
				} unset($result);
			}
		} else
		if ($action == 'moveup' || $action == 'cmoveup') { $n1 = $num-1;
			echo '<h3>'.t('move_up').'</h3>';
			$query = "SELECT * FROM ".PREFIX.$form['query_table'];
			$query .= $order."(order_content = $num OR order_content = $n1) ORDER BY order_content ASC LIMIT 2;";
			$query = str_replace('%lang_id', $language, $query);
			if ($result = db() -> query($query)){
				while ($r = dbfetch($result)) { $id = $r['id'];
					$qm = "UPDATE ".PREFIX.$form['query_table']." SET order_content = ? WHERE id = ?;";
					if ($qx = db() -> prepare($qm)){
						dbbind($qx, array($num, $id), 'ii');
						$rx = dbfetch($qx);
						$num--; unset($qx);
					}
				} unset($result);
			}
		}
		if ($action == 'cmoveup' || $action == 'cmovedown') {
			$table_fields = isset($form['content_fields']) ? $form['content_fields'] : '';
			$id = isset($get[$form['inherited_id']]) ? $get[$form['inherited_id']] : 0;
			$query = "SELECT a.$form[inherited_id], b.id, b.key_security 
				FROM ".PREFIX.$form['query_table']." AS a 
				LEFT JOIN ".PREFIX.$form['inherited']." AS b 
					ON b.id = a.$form[inherited_id]
				WHERE b.id = ".$tid;
			$query = str_replace('%lang_id', $language, $query);
			if ($result = db() -> query($query)){
				$sql = dbfetch($result);
				$tid = $sql['id'];
				$tks = $sql['key_security']; $tks = encryptRSA($tks, false);
			} unset($sql);
			$link = $root.'?admin='.$form['inherited'].'&amp;action=content&amp;tid='.$tid.'&amp;tks=';
			$link .= $tks.$ukey.$lang;
			echo '<meta http-equiv="refresh" content="2; url='.$link.'">'; return;
		} echo '<meta http-equiv="refresh" content="1; url='.$root.'?admin='.$gadmin.'&amp;action=list';
		echo $ukey.$pn.$lang.'">';
	} else
	
# **************************************************************************************************************
# --------------------------------------------------------------------------------------------------------------
#
#						i  P  L  U  G  I  N  S
#
# --------------------------------------------------------------------------------------------------------------
# **************************************************************************************************************
	if ($action == 'install' || $action == 'dtable' || $action == 'ctable' ) {
		$id = isset($get['tid']) ? $get['tid'] : null;
	 	$key = $action == 'install' ? 'tks': 'dks';
	 	$tks = decryptRSA($get[$key]);
	 	$data = retrieve_mysql('plugins', 'id', $id, 'filename', " AND key_security = '$tks'");
	 	if (!$data) {set_error(); return;}
	 	$fname = 'plugin_'.load_value('getfilename',$data['filename']);
	 	if (function_exists($fname)) {call_user_func_array($fname, array($action, $data['filename']));}
		echo '<meta http-equiv="refresh" content="2; url='.$root.'?admin=iplugins&amp;action=list'.$ukey.'">';
	}
	
# **************************************************************************************************************
# --------------------------------------------------------------------------------------------------------------
#
#							U  N  K  N  O  W  N     C  O  M  M  A  N  D
#
# --------------------------------------------------------------------------------------------------------------
# **************************************************************************************************************
	else {echo '<meta http-equiv="refresh" content="0; url='.$root.'?error=404">';}
}
?>